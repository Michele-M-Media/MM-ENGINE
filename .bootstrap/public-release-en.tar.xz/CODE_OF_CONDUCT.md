# Community conduct

Be respectful, constructive and technically focused.

Harassment, personal attacks, discriminatory conduct, doxxing, threats and deliberate disruption are not welcome.

When reporting a problem, provide reproducible information where possible. When reviewing a contribution, critique the code and evidence rather than the contributor.

Maintainers may remove content or participation that materially harms the project or its community.
