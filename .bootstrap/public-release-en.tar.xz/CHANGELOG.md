# Changelog

## 0.1.0-alpha - bootstrap

- Added portable engine clock, diagnostics, services, scene/GameObject/component lifecycle, hierarchy transforms, and reflection-free text scenes.
- Added deterministic `.mmmesh` v1 codec plus OBJ and GLB conversion/validation CLI, including baked `KHR_texture_transform` UVs and explicit unsupported-material warnings.
- Added stable DualSense snapshot, pressed/held/released, vibration, and light-bar APIs.
- Added native SharpProspero 2D image, alpha, scaling, nine-slice, TrueType/bitmap text, and UI layers.
- Added AGC multi-draw 3D renderer using the SDK's embedded shader pair and compact per-submesh GPU buffers.
- Added connected per-frame diagnostics, a host GNF conversion front end, four package-ready samples, nine portable tests, build wrappers, audit, and hardware plan.
- Kept depth, 3D texture sampling/blending, and tiled mixed CPU/GPU composition explicitly blocked pending verified SDK support.
