"""Read-only, bounded context collection from allowlisted workspaces."""
from __future__ import annotations
import hashlib
from pathlib import Path
from difflib import unified_diff

SKIP_DIRS = {'.git', '.venv', 'node_modules', 'vendor', 'dist', 'build', '__pycache__', '.idea'}
SKIP_SUFFIXES = {'.pem', '.key', '.p12', '.pfx', '.bin', '.iso', '.zip', '.exe', '.dll', '.so', '.png', '.jpg', '.pdf'}
CODE_SUFFIXES = {'.py', '.rs', '.c', '.h', '.cpp', '.hpp', '.ts', '.js', '.json', '.md', '.toml', '.yaml', '.yml', '.cs', '.go', '.java', '.sh', '.ps1', '.txt'}

def safe_path(root: Path, rel: str) -> Path:
    if not isinstance(rel, str) or not rel or len(rel)>250 or rel.startswith(('/', '\\')) or '\\' in rel:
        raise ValueError('Percorso non valido')
    p = Path(rel)
    if p.is_absolute() or '..' in p.parts or any(part.startswith('.') for part in p.parts):
        raise ValueError('Percorso nascosto o esterno')
    if any(part in SKIP_DIRS for part in p.parts) or p.suffix.lower() in SKIP_SUFFIXES:
        raise ValueError('Percorso escluso')
    if any(k in p.name.lower() for k in ('secret','credential','password','token','private-key')):
        raise ValueError('File riservato escluso')
    source = root / p
    if not source.resolve().is_relative_to(root.resolve()):
        raise ValueError('Symlink/path escape non consentito')
    if source.exists() and (not source.is_file() or source.is_symlink()):
        raise ValueError('Solo file regolari senza symlink')
    return source

def sha(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def snapshot(root: Path, max_files: int = 30, max_chars: int = 36000) -> str:
    if not root.is_dir():
        raise ValueError('Workspace non trovato')
    seen=[]; used=0
    for p in sorted(root.rglob('*')):
        if not p.is_file() or p.is_symlink() or len(seen)>=max_files or used>=max_chars:
            continue
        rel = p.relative_to(root)
        if any(part in SKIP_DIRS or part.startswith('.') for part in rel.parts) or p.suffix.lower() not in CODE_SUFFIXES:
            continue
        try:
            safe_path(root, rel.as_posix())
            if p.stat().st_size>45_000: continue
            s=p.read_text(encoding='utf-8', errors='replace')[:6000]
        except (OSError, ValueError): continue
        s=s[:max_chars-used]
        seen.append(f'FILE {rel.as_posix()} sha256={sha(s)}\n{s}')
        used += len(s)
    return '\n\n'.join(seen) if seen else 'Nessun file testuale sicuro trovato.'

def diff(old: str, new: str, rel: str) -> str:
    return ''.join(unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
                fromfile='a/'+rel, tofile='b/'+rel))
