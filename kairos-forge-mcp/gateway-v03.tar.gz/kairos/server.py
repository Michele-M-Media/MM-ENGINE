"""Streamable HTTP MCP JSON-RPC gateway tested via ASGI. No proprietary CLIs.

For deployment the endpoint MUST be behind HTTPS and the server requires a
nonempty private token. ChatGPT auth configuration must be tested on the account.
"""
from __future__ import annotations
import json, os, secrets
from pathlib import Path
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse, Response, PlainTextResponse
from starlette.routing import Route
from .agents import backend_from_env, ROLES
from .council import Council
from .editor import ChangeEngine
from .audit import AuditLog
from .inspector import tree, read_file, find_text, git_read
from .runner import CheckQueue
from .transaction import BatchEngine
from .relay import Relay

# Only admin-side environment values are trusted. No remote URLs in tool arguments.
def workspace_config():
    x=json.loads(os.getenv('KAIROS_WORKSPACES','{}'))
    if not isinstance(x,dict) or not all(isinstance(k,str) and k and isinstance(v,str) for k,v in x.items()):
        raise ValueError('KAIROS_WORKSPACES deve essere JSON alias:directory')
    return x

def check_config():
    x=json.loads(os.getenv('KAIROS_CHECKS','{}'))
    if not isinstance(x,dict): raise ValueError('KAIROS_CHECKS non valido')
    return x

backend=backend_from_env()
council=Council(backend,workspace_config(),os.getenv('KAIROS_STATE_DIR','./kairos-state'))
editor=ChangeEngine(council,check_config())
audit=AuditLog(council.state_dir/'audit.jsonl',os.getenv('KAIROS_AUDIT_KEY',''))
check_queue=CheckQueue(council.workspaces,check_config(),council.state_dir,audit)
batch=BatchEngine(council.workspaces,council.state_dir,check_config(),audit)
workers=json.loads(os.getenv('KAIROS_REMOTE_WORKERS','{}'))
if not isinstance(workers,dict) or not all(isinstance(k,str) and isinstance(v,list) and all(isinstance(alias,str) for alias in v) for k,v in workers.items()):
    raise ValueError('KAIROS_REMOTE_WORKERS richiede JSON worker:[alias,...]')
relay=Relay(council.state_dir,workers,audit)

def fields(props=None, required=None):
    return {'type':'object','properties':props or {},'required':required or [],'additionalProperties':False}
def sval(desc): return {'type':'string','description':desc}
def bval(desc): return {'type':'boolean','description':desc}
TOOLS=[
 ('kairos_status', 'Mostra i tre agenti Kairos originali, disponibilita del modello gratuito e workspace.', fields()),
 ('kairos_project', 'Legge un riassunto bounded dei file autorizzati, senza toccare sorgenti.',fields({'workspace':sval('Alias workspace autorizzato')},['workspace'])),
 ('kairos_static_review', 'Tre verificatori Kairos originali analizzano in parallelo struttura, sintassi e indicatori di rischio, senza crediti API.',fields({'workspace':sval('Alias workspace')},['workspace'])),
 ('kairos_council_start', 'Avvia Architect, Developer e Verifier in parallelo; revisione reciproca e voto, SOLO LETTURA.',fields({'task':sval('Obiettivo sviluppo'),'workspace':sval('Alias workspace')},['task','workspace'])),
 ('kairos_council_get', 'Stato, proposte, critiche e voti del consiglio.',fields({'job_id':sval('ID riunione')},['job_id'])),
 ('kairos_council_approve', 'Registra approvazione esplicita del piano, senza scrittura.',fields({'job_id':sval('ID riunione'),'approved':bval('Conferma esplicita utente')},['job_id','approved'])),
 ('kairos_patch_propose', 'Genera una patch Kairos Developer e restituisce un diff; NON modifica il file.',fields({'job_id':sval('ID riunione approvata'),'path':sval('File relativo al workspace'),'instruction':sval('Modifica desiderata')},['job_id','path','instruction'])),
 ('kairos_patch_stage_from_chat', 'Staging sicuro di codice generato da ChatGPT stesso: nessun modello/API esterna; restituisce diff, NON scrive nel progetto.',fields({'workspace':sval('Workspace autorizzato'),'path':sval('Percorso relativo'),'content':sval('Contenuto completo proposto da ChatGPT')},['workspace','path','content'])),
 ('kairos_patch_preview', 'Mostra il diff prima della modifica.',fields({'stage_id':sval('ID proposta')},['stage_id'])),
 ('kairos_patch_approve', 'Registra consenso esplicito al diff, senza scrivere.',fields({'stage_id':sval('ID proposta'),'approved':bval('Conferma esplicita utente')},['stage_id','approved'])),
 ('kairos_patch_apply', 'Applica SOLO una patch approvata, esegue check amministratore e rollback in caso di errore.',fields({'stage_id':sval('ID proposta approvata')},['stage_id'])),
 ('kairos_tree','Esplora l’albero dei file sicuri del workspace, senza crediti API.',fields({'workspace':sval('Alias autorizzato')},['workspace'])),
 ('kairos_read','Legge righe di un file sicuro con hash per prevenire overwrite.',fields({'workspace':sval('Alias autorizzato'),'path':sval('Percorso relativo'),'start_line':{'type':'integer','minimum':1},'max_lines':{'type':'integer','minimum':1,'maximum':250}},['workspace','path'])),
 ('kairos_search','Ricerca testo nel codice senza aprire shell o fare richieste AI esterne.',fields({'workspace':sval('Alias autorizzato'),'query':sval('Testo da cercare'),'case_sensitive':bval('Case sensitive')},['workspace','query'])),
 ('kairos_git','Git STATUS/DIFF/LOG in sola lettura, senza scrittura repository.',fields({'workspace':sval('Alias autorizzato'),'action':{'type':'string','enum':['status','diff','log']},'path':sval('Solo per diff, file relativo opzionale')},['workspace','action'])),
 ('kairos_checks_start','Avvia SOLO i check/build preconfigurati dal proprietario. Non accetta comandi shell.',fields({'workspace':sval('Alias autorizzato')},['workspace'])),
 ('kairos_checks_get','Stato e log dei check realmente eseguiti.',fields({'job_id':sval('ID check')},['job_id'])),
 ('kairos_checks_cancel','Annulla i check in esecuzione.',fields({'job_id':sval('ID check')},['job_id'])),
 ('kairos_batch_stage','Prepara una transazione multi-file (max 8) da codice generato nella chat. Nessuna scrittura.',fields({'workspace':sval('Alias autorizzato'),'changes':{'type':'array','items':{'type':'object','properties':{'path':sval('File relativo'),'content':sval('Contenuto completo')},'required':['path','content'],'additionalProperties':False},'minItems':1,'maxItems':8}},['workspace','changes'])),
 ('kairos_batch_preview','Diff e hash della transazione, da verificare prima di approvare.',fields({'stage_id':sval('ID transazione')},['stage_id'])),
 ('kairos_batch_approve','Registra approvazione espressa del diff dopo richiesta alla persona. Non scrive file.',fields({'stage_id':sval('ID transazione'),'approval_phrase':sval('APPROVO seguito da primi otto caratteri ID')},['stage_id','approval_phrase'])),
 ('kairos_batch_apply','Applica una transazione autorizzata. Un writer, test configurati, rollback completo.',fields({'stage_id':sval('ID transazione')},['stage_id'])),
 ('kairos_batch_undo','Annulla transazione gia applicata soltanto se i file non sono cambiati.',fields({'stage_id':sval('ID transazione'),'approval_phrase':sval('ANNULLA seguito da primi otto caratteri ID')},['stage_id','approval_phrase'])),
 ('kairos_audit','Verifica la catena di audit senza esporre contenuti sorgente.',fields()),
 ('kairos_council_cancel','Annulla una discussione degli agenti Kairos.',fields({'job_id':sval('ID consiglio')},['job_id'])),
 ('kairos_remote_workers','Mostra PC autorizzati e online/offline; nessun credential.',fields()),
 ('kairos_remote_enqueue','Invia lavoro sicuro al PC abilitato: tree/read/search/git_status/checks, MAI shell arbitraria.',fields({'worker':sval('ID PC autorizzato'),'workspace':sval('Alias locale concesso'),'operation':{'type':'string','enum':['tree','read','search','git_status','checks']},'path':sval('Percorso relativo per read'),'query':sval('Testo di ricerca per search')},['worker','workspace','operation'])),
 ('kairos_remote_status','Legge stato e risultato restituito dal PC alla chat web.',fields({'job_id':sval('ID lavoro remoto')},['job_id'])),
]
async def dispatch(name,args):
    from .workspace import snapshot
    if name=='kairos_status':
        return {'agents':[{'name':n,'available':await backend.available(n)} for n in ROLES],
                'model':getattr(backend,'model',None),'workspaces':list(council.workspaces),
                'external_paid_api_enabled':False,'proprietary_cli_enabled':False}
    if name=='kairos_project':
        a=args['workspace'];root=council.workspaces[a]
        return {'workspace':a,'context':snapshot(root)}
    if name=='kairos_static_review':
        from .static_review import run_static_review
        return await run_static_review(council.workspaces[args['workspace']])
    if name=='kairos_council_start': return await council.start(args['task'],args['workspace'],list(ROLES))
    if name=='kairos_council_get': return council.get(args['job_id'])
    if name=='kairos_council_approve': return council.approve(args['job_id'],args['approved'])
    if name=='kairos_patch_propose': return await editor.propose(args['job_id'],args['path'],args['instruction'])
    if name=='kairos_patch_stage_from_chat': return editor.stage_from_chat(args['workspace'],args['path'],args['content'])
    if name=='kairos_patch_preview': return editor.preview(args['stage_id'])
    if name=='kairos_patch_approve': return editor.approve(args['stage_id'],args['approved'])
    if name=='kairos_patch_apply': return await editor.apply(args['stage_id'])
    if name=='kairos_tree':return tree(council.workspaces[args['workspace']])
    if name=='kairos_read':return read_file(council.workspaces[args['workspace']],args['path'],args.get('start_line',1),args.get('max_lines',180))
    if name=='kairos_search':return find_text(council.workspaces[args['workspace']],args['query'],args.get('case_sensitive',False))
    if name=='kairos_git':return await git_read(council.workspaces[args['workspace']],args['action'],args.get('path'))
    if name=='kairos_checks_start':return check_queue.start(args['workspace'])
    if name=='kairos_checks_get':return check_queue.get(args['job_id'])
    if name=='kairos_checks_cancel':return check_queue.cancel(args['job_id'])
    if name=='kairos_batch_stage':return batch.propose(args['workspace'],args['changes'])
    if name=='kairos_batch_preview':return batch.preview(args['stage_id'])
    if name=='kairos_batch_approve':return batch.approve(args['stage_id'],args['approval_phrase'])
    if name=='kairos_batch_apply':return await batch.apply(args['stage_id'])
    if name=='kairos_batch_undo':return await batch.undo(args['stage_id'],args['approval_phrase'])
    if name=='kairos_audit':return audit.verify()
    if name=='kairos_council_cancel':return council.cancel(args['job_id'])
    if name=='kairos_remote_workers':return {'workers':relay.workers_status()}
    if name=='kairos_remote_enqueue':return relay.enqueue(args['worker'],args['workspace'],args['operation'],args.get('path',''),args.get('query',''))
    if name=='kairos_remote_status':return relay.status(args['job_id'])
    raise KeyError(name)

async def mcp_post(request:Request):
    token=os.getenv('KAIROS_MCP_TOKEN','')
    supplied=request.headers.get('authorization','')
    if len(token)<32: return PlainTextResponse('Server not securely configured',status_code=503)
    if not secrets.compare_digest(supplied,'Bearer '+token):
        return PlainTextResponse('Unauthorized',status_code=401)
    if int(request.headers.get('content-length','0') or 0)>90000:
        return PlainTextResponse('Request too large',status_code=413)
    try:
        chunks=[];size=0
        async for chunk in request.stream():
            size+=len(chunk)
            if size>90_000:return PlainTextResponse('Request too large',status_code=413)
            chunks.append(chunk)
        data=json.loads(b''.join(chunks))
    except (json.JSONDecodeError,UnicodeDecodeError):return PlainTextResponse('Invalid JSON',status_code=400)
    if not isinstance(data,dict):return PlainTextResponse('Invalid JSONRPC object',status_code=400)
    method=data.get('method'); req_id=data.get('id')
    if method=='notifications/initialized':return Response(status_code=202)
    def out(result=None,error=None):
        v={'jsonrpc':'2.0','id':req_id}
        if error:v['error']=error
        else:v['result']=result
        return JSONResponse(v,headers={'Cache-Control':'no-store'})
    if method=='initialize':
        return out({'protocolVersion':'2025-03-26','capabilities':{'tools':{'listChanged':False}},
                    'serverInfo':{'name':'kairos-forge-pro','version':'0.2.0'},
                    'instructions':'Kairos Forge PRO. Strumenti per file, Git, build, council e patch. Nessuna CLI proprietaria, nessuna API a pagamento. Verifica e chiedi autorizzazione prima di scrivere. Un writer alla volta; non simulare test o risultati.'})
    if method=='ping':return out({})
    if method=='tools/list':
        return out({'tools':[{'name':n,'description':d,'inputSchema':s,'annotations':{
            'readOnlyHint': n not in {'kairos_patch_approve','kairos_patch_apply','kairos_batch_stage','kairos_batch_approve','kairos_batch_apply','kairos_batch_undo','kairos_checks_start','kairos_checks_cancel','kairos_council_approve','kairos_council_start','kairos_council_cancel','kairos_patch_propose','kairos_patch_stage_from_chat','kairos_remote_enqueue'},
            'destructiveHint':n in {'kairos_patch_apply','kairos_batch_apply','kairos_batch_undo'},
            'openWorldHint':False}} for n,d,s in TOOLS]})
    if method=='tools/call':
        params=data.get('params') or {}
        name=params.get('name');args=params.get('arguments') or {}
        if not isinstance(args,dict) or name not in {i[0] for i in TOOLS}:
            return out(error={'code':-32602,'message':'Tool o argomenti non validi'})
        try:
            value=await dispatch(name,args)
            return out({'content':[{'type':'text','text':json.dumps(value,ensure_ascii=False)}], 'isError':False})
        except (KeyError,ValueError,PermissionError,RuntimeError,OSError,TypeError) as exc:
            return out({'content':[{'type':'text','text':f'{type(exc).__name__}: {str(exc)[:320]}'}], 'isError':True})
    return out(error={'code':-32601,'message':'Method not found'})

async def worker_api(request:Request):
    # The worker token MUST be separate from the ChatGPT/MCP token.
    configured=os.getenv('KAIROS_WORKER_TOKEN','')
    if len(configured)<32 or not workers:
        return PlainTextResponse('Worker relay unavailable',status_code=503)
    if not secrets.compare_digest(request.headers.get('authorization',''),'Bearer '+configured):
        return PlainTextResponse('Unauthorized',status_code=401)
    try:
        chunks=[];total=0
        async for chunk in request.stream():
            total+=len(chunk)
            if total>35000:return PlainTextResponse('Payload too large',status_code=413)
            chunks.append(chunk)
        args=json.loads(b''.join(chunks))
        if not isinstance(args,dict):raise ValueError('Invalid body')
        name=request.url.path
        if name=='/worker/claim':
            job=relay.claim(args['worker']);result={'job':job}
        elif name=='/worker/complete':
            result=relay.complete(args['worker'],args['job_id'],args['lease_token'],args['result'])
        elif name=='/worker/heartbeat':
            result=relay.heartbeat(args['worker'])
        else:raise ValueError('Unknown operation')
        return JSONResponse(result,headers={'Cache-Control':'no-store'})
    except (json.JSONDecodeError,TypeError,KeyError,ValueError,PermissionError) as exc:
        return JSONResponse({'error':f'{type(exc).__name__}: {str(exc)[:180]}'},status_code=400)

async def health(request):
    return JSONResponse({'server':'kairos-forge-pro','status':'ready','external_paid_api_enabled':False,
                         'model_configured':bool(getattr(backend,'model',None))})

app=Starlette(routes=[Route('/mcp',mcp_post,methods=['POST']),Route('/health',health,methods=['GET']),Route('/worker/claim',worker_api,methods=['POST']),Route('/worker/complete',worker_api,methods=['POST']),Route('/worker/heartbeat',worker_api,methods=['POST'])])
