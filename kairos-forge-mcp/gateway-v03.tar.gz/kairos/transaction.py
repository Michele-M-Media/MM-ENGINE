"""Two-phase, multi-file change engine with SHA conflicts and full rollback.

An agent cannot directly write source files. The user reviews the diff before
approval. The runner only executes fixed administrator-configured checks.
"""
from __future__ import annotations
import asyncio
import json
import os
import time
from uuid import uuid4
from pathlib import Path
from .workspace import safe_path, sha, diff, CODE_SUFFIXES
from .runner import run_check_sequence
from .audit import AuditLog

MAX_FILES=8
MAX_BATCH_BYTES=240_000
TTL=24*60*60

class BatchEngine:
    def __init__(self, workspaces:dict[str,Path], state_dir:Path, checks:dict, audit:AuditLog):
        self.workspaces=workspaces
        self.dir=state_dir/'batch_stages'
        self.dir.mkdir(parents=True,exist_ok=True)
        self.checks=checks
        self.audit=audit
        self.locks:dict[str,asyncio.Lock]={}
        self.recover_interrupted()

    def recover_interrupted(self) -> None:
        """Recover a batch interrupted by process termination, without clobbering
        unrelated edits made after the interruption. One server process only.
        """
        for stage_file in self.dir.glob('*.json'):
            try:
                doc=json.loads(stage_file.read_text(encoding='utf-8'))
                if doc.get('state')!='applying':continue
                root=self.workspaces.get(doc.get('workspace'))
                if root is None:continue
                uncertain=[]
                for item in doc.get('changes',[]):
                    target=safe_path(root,item['path'])
                    if target.exists():
                        current=sha(target.read_text(encoding='utf-8'))
                    else: current=sha('')
                    if current not in {item['old_sha'],item['new_sha']}:
                        uncertain.append(item['path'])
                if uncertain:
                    doc['state']='manual_recovery_required'
                    doc['recovery_conflicts']=uncertain
                else:
                    for item in reversed(doc['changes']):
                        target=safe_path(root,item['path'])
                        if item['existed']:
                            target.parent.mkdir(parents=True,exist_ok=True)
                            tmp=target.with_name(target.name+'.kairos-recovery.tmp')
                            tmp.write_text(item['before'],encoding='utf-8')
                            os.replace(tmp,target)
                        elif target.exists():target.unlink()
                    doc['state']='recovered_after_interruption'
                self._save(doc)
                self.audit.record('batch_recovery',workspace=doc['workspace'],stage_id=doc['id'],status=doc['state'])
            except (OSError,KeyError,ValueError,TypeError):
                # Corrupt journal or filesystem permissions must be investigated.
                continue

    def _path(self, sid:str)->Path:
        if len(sid)!=32 or any(c not in '0123456789abcdef' for c in sid):raise ValueError('ID batch non valido')
        return self.dir/(sid+'.json')

    def _load(self,sid:str)->dict:
        try:return json.loads(self._path(sid).read_text(encoding='utf-8'))
        except FileNotFoundError:raise ValueError('Batch inesistente') from None

    def _save(self,doc):
        path=self._path(doc['id'])
        tmp=path.with_suffix('.tmp')
        tmp.write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(tmp,path)

    def propose(self,workspace:str,changes:list[dict])->dict:
        if workspace not in self.workspaces:raise ValueError('Workspace non autorizzato')
        if not isinstance(changes,list) or not 1<=len(changes)<=MAX_FILES:
            raise ValueError('Da 1 a 8 file richiesti')
        root=self.workspaces[workspace]
        if not root.is_dir():raise ValueError('Workspace non disponibile')
        source=[];seen=set();size=0
        for item in changes:
            if not isinstance(item,dict):raise ValueError('Formato file errato')
            path=item.get('path');content=item.get('content')
            if not isinstance(content,str) or not isinstance(path,str):raise ValueError('Path e content devono essere stringhe')
            if path in seen:raise ValueError('File duplicato')
            seen.add(path)
            target=safe_path(root,path)
            if target.suffix.lower() not in CODE_SUFFIXES:raise ValueError('Estensione non consentita')
            if target.exists() and target.stat().st_size>120_000:raise ValueError('File troppo grande')
            before=target.read_text(encoding='utf-8') if target.exists() else ''
            size +=len(before.encode())+len(content.encode())
            if size>MAX_BATCH_BYTES:raise ValueError('Batch troppo grande')
            if sha(before)==sha(content):continue
            source.append({'path':path,'before':before,'old_sha':sha(before),'new_sha':sha(content),
                           'content':content,'diff':diff(before,content,path),'existed':target.exists()})
        if not source:raise ValueError('Nessuna differenza')
        sid=uuid4().hex
        doc={'id':sid,'workspace':workspace,'state':'proposed','created_at':time.time(),
             'approved':False,'changes':source,'checks':[]}
        self._save(doc)
        self.audit.record('batch_proposed',workspace=workspace,stage_id=sid,files=len(source),bytes=size)
        return self.preview(sid)

    def preview(self,sid:str)->dict:
        doc=self._load(sid)
        return {'id':sid,'workspace':doc['workspace'],'state':doc['state'],'approved':doc['approved'],
                'files':[{'path':x['path'],'old_sha':x['old_sha'],'new_sha':x['new_sha'],'diff':x['diff'][:24_000]} for x in doc['changes']],
                'expires_at':doc['created_at']+TTL}

    def approve(self,sid:str,phrase:str)->dict:
        doc=self._load(sid)
        if doc['state']!='proposed':raise ValueError('Batch non approvabile')
        if time.time()-doc['created_at']>TTL:raise ValueError('Proposta scaduta')
        if phrase!=f'APPROVO {sid[:8]}':
            raise PermissionError('Richiede approvazione espressa per il batch corrente')
        doc['approved']=True;doc['state']='approved';self._save(doc)
        self.audit.record('batch_approved',workspace=doc['workspace'],stage_id=sid)
        return {'id':sid,'state':'approved','note':'Nessun file ancora scritto'}

    async def apply(self,sid:str)->dict:
        doc=self._load(sid)
        workspace=doc['workspace']
        lock=self.locks.setdefault(workspace,asyncio.Lock())
        async with lock:
            doc=self._load(sid)
            if doc['state']!='approved' or not doc['approved']:raise PermissionError('Batch non approvato oppure consumato')
            if time.time()-doc['created_at']>TTL:raise ValueError('Approvazione scaduta')
            root=self.workspaces[workspace]
            # Optimistic conflict detection for *every* file, before writing any.
            for item in doc['changes']:
                target=safe_path(root,item['path'])
                current=target.read_text(encoding='utf-8') if target.exists() else ''
                if sha(current)!=item['old_sha'] or target.exists()!=item['existed']:
                    raise RuntimeError(f'Conflitto: {item["path"]} è cambiato prima dell\'applicazione')
            written=[]
            doc['state']='applying';self._save(doc)
            try:
                for item in doc['changes']:
                    target=safe_path(root,item['path'])
                    target.parent.mkdir(parents=True,exist_ok=True)
                    # Verify a newly created parent did not introduce an escape.
                    target=safe_path(root,item['path'])
                    if target.exists() and sha(target.read_text(encoding='utf-8'))!=item['old_sha']:
                        raise RuntimeError('Conflitto durante la scrittura')
                    temp=target.with_name(target.name+'.kairos-'+sid+'.tmp')
                    temp.write_text(item['content'],encoding='utf-8')
                    os.replace(temp,target)
                    written.append(item)
                results,ok=await run_check_sequence(root,self.checks.get(workspace,[]))
                if not ok:raise CheckFailure(results)
                doc['state']='applied';doc['checks']=results;doc['applied_at']=time.time()
                self._save(doc)
                self.audit.record('batch_applied',workspace=workspace,stage_id=sid,files=len(written),checks=len(results))
                return {'id':sid,'state':'applied','paths':[x['path'] for x in written],
                        'checks':results,'verification':'checks_passed' if results else 'no_checks_configured'}
            except BaseException as exc:
                # Restore all changed files, including on task cancellation.
                rollback_errors=[]
                for item in reversed(written):
                    try:
                        target=safe_path(root,item['path'])
                        if item['existed']:
                            temp=target.with_name(target.name+'.kairos-restore-'+sid+'.tmp')
                            temp.write_text(item['before'],encoding='utf-8')
                            os.replace(temp,target)
                        elif target.exists():target.unlink()
                    except Exception as restore_exc:
                        rollback_errors.append(str(restore_exc)[:200])
                doc['state']='rollback_incomplete' if rollback_errors else 'rolled_back'
                doc['failure']=f'{type(exc).__name__}: {str(exc)[:500]}'
                doc['checks']=getattr(exc,'results',[])
                doc['rollback_errors']=rollback_errors
                self._save(doc)
                self.audit.record('batch_failed',workspace=workspace,stage_id=sid,status=doc['state'])
                if isinstance(exc,asyncio.CancelledError):raise
                return {'id':sid,'state':doc['state'],'error':doc['failure'],'checks':doc['checks'],
                        'rollback_errors':rollback_errors}

    async def undo(self,sid:str,phrase:str)->dict:
        # Undo a successful batch only if no file has changed after apply.
        doc=self._load(sid)
        workspace=doc['workspace']
        if phrase!=f'ANNULLA {sid[:8]}':raise PermissionError('Conferma annullamento esplicita mancante')
        lock=self.locks.setdefault(workspace,asyncio.Lock())
        async with lock:
            doc=self._load(sid)
            if doc['state']!='applied':raise ValueError('Batch non annullabile')
            root=self.workspaces[workspace]
            for item in doc['changes']:
                target=safe_path(root,item['path'])
                if not target.exists() or sha(target.read_text(encoding='utf-8'))!=item['new_sha']:
                    raise RuntimeError('Un file è cambiato dopo la patch, annullamento bloccato')
            for item in reversed(doc['changes']):
                target=safe_path(root,item['path'])
                if item['existed']:
                    tmp=target.with_name(target.name+'.kairos-undo-'+sid+'.tmp')
                    tmp.write_text(item['before'],encoding='utf-8');os.replace(tmp,target)
                else:target.unlink()
            doc['state']='undone';self._save(doc)
            self.audit.record('batch_undone',workspace=workspace,stage_id=sid)
            return {'id':sid,'state':'undone','files':[x['path'] for x in doc['changes']]}

class CheckFailure(Exception):
    def __init__(self,results):
        super().__init__('Check di verifica fallito')
        self.results=results
