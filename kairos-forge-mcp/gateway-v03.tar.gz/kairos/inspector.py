"""Bounded repository inspection (no shell, no content from hidden/secret files)."""
from __future__ import annotations
import asyncio
import os
import subprocess
from pathlib import Path
from .workspace import CODE_SUFFIXES, SKIP_DIRS, safe_path, sha

MAX_FILE_BYTES = 100_000
MAX_RESULTS = 60


def tree(root: Path, limit: int = 180) -> dict:
    if not root.is_dir(): raise ValueError('Workspace inesistente')
    rows = []
    limit = min(max(limit, 1), 250)
    def visit(base: Path, depth: int):
        if depth > 8 or len(rows) >= limit: return
        for p in sorted(base.iterdir(), key=lambda x: x.name):
            if len(rows)>=limit: return
            name = p.name
            if name.startswith('.') or name in SKIP_DIRS or p.is_symlink(): continue
            rel = p.relative_to(root).as_posix()
            if p.is_dir():
                rows.append({'path':rel, 'kind':'directory'})
                visit(p,depth+1)
            elif p.is_file() and p.suffix.lower() in CODE_SUFFIXES:
                try:
                    checked = safe_path(root, rel)
                    if checked.stat().st_size <= 300_000:
                        rows.append({'path':rel, 'kind':'file','bytes':checked.stat().st_size})
                except (OSError,ValueError):pass
    visit(root,0)
    return {'entries': rows, 'truncated':len(rows)>=limit, 'max_entries':limit}


def read_file(root:Path, rel:str, start_line:int=1, max_lines:int=180) -> dict:
    p = safe_path(root, rel)
    if p.suffix.lower() not in CODE_SUFFIXES: raise ValueError('Estensione non consentita')
    if not p.is_file() or p.stat().st_size>MAX_FILE_BYTES: raise ValueError('File mancante o troppo grande')
    if not 1 <= start_line <= 500_000: raise ValueError('Numero di linea non valido')
    max_lines=min(max(1,max_lines),250)
    contents=p.read_text(encoding='utf-8')
    lines=contents.splitlines()
    ending=min(len(lines),start_line+max_lines-1)
    return {'path':rel,'sha256':sha(contents),'total_lines':len(lines),'start_line':start_line,
            'end_line':ending,'lines':[{'number':i+1,'text':lines[i]} for i in range(start_line-1,ending)],
            'truncated':ending<len(lines)}


def find_text(root:Path, needle:str, case_sensitive:bool=False, max_results:int=30) -> dict:
    if not isinstance(needle,str) or not 2<=len(needle)<=120: raise ValueError('Stringa di ricerca non valida')
    max_results=min(max(max_results,1),MAX_RESULTS)
    q=needle if case_sensitive else needle.casefold()
    found=[]; scanned=0
    for file in root.rglob('*'):
        if len(found)>=max_results or scanned>=600:break
        if not file.is_file() or file.is_symlink() or file.suffix.lower() not in CODE_SUFFIXES:continue
        rel=file.relative_to(root)
        if any(x.startswith('.') or x in SKIP_DIRS for x in rel.parts): continue
        try:
            safe_path(root,rel.as_posix())
            if file.stat().st_size>MAX_FILE_BYTES:continue
            lines=file.read_text(encoding='utf-8').splitlines()
        except (OSError,UnicodeError,ValueError):continue
        scanned+=1
        for i,line in enumerate(lines,1):
            if q in (line if case_sensitive else line.casefold()):
                found.append({'file':rel.as_posix(),'line':i,'snippet':line[:320]})
                if len(found)>=max_results:break
    return {'matches':found, 'files_scanned':scanned, 'truncated':len(found)>=max_results}


async def git_read(root:Path, action:str, rel:str|None=None) -> dict:
    if action not in ('status','diff','log'):raise ValueError('Comando Git non consentito')
    args=['git','-C',str(root),'--no-pager']
    if action=='status':args+=['status','--short','--branch','--untracked-files=normal']
    elif action=='diff':
        args+=['diff','--no-ext-diff','--no-textconv','--']
        if rel:
            safe_path(root,rel)
            args.append(rel)
    else:args+=['log','-8','--format=%h %as %s']
    env={k:v for k,v in os.environ.items() if k not in {'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT'}}
    env.update({'GIT_PAGER':'cat','GIT_OPTIONAL_LOCKS':'0','GIT_EXTERNAL_DIFF':'','GIT_CONFIG_NOSYSTEM':'1'})
    try:
        p=await asyncio.create_subprocess_exec(*args, stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT,env=env)
        output,_=await asyncio.wait_for(p.communicate(),timeout=12)
    except FileNotFoundError:raise RuntimeError('Git non installato') from None
    except asyncio.TimeoutError:
        p.kill();await p.wait();raise RuntimeError('Git ha superato il tempo limite') from None
    return {'action':action,'exit_code':p.returncode,'output':output.decode(errors='replace')[:16000]}
