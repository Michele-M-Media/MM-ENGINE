"""Append-only integrity-chained audit events, excluding source contents/secrets."""
from __future__ import annotations
import hashlib
import hmac
import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class AuditLog:
    def __init__(self, path: str | Path, key: str = ''):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.key = key.encode('utf-8')
        self.lock = threading.Lock()
        self.previous = '0' * 64
        if self.path.exists():
            with self.path.open('r', encoding='utf-8') as reader:
                for line in reader:
                    if line.strip():
                        self.previous = json.loads(line)['hash']

    def _digest(self, data: dict[str, Any]) -> str:
        value = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
        return hmac.new(self.key, value, 'sha256').hexdigest() if self.key else hashlib.sha256(value).hexdigest()

    def record(self, event: str, *, workspace: str | None = None, **metadata: Any) -> dict:
        # Callers pass only IDs, counts, hashes and status; never source or prompts.
        with self.lock:
            item = {
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'event': event[:80],
                'workspace': workspace,
                'metadata': metadata,
                'previous': self.previous,
            }
            item['hash'] = self._digest(item)
            with self.path.open('a', encoding='utf-8') as writer:
                writer.write(json.dumps(item, ensure_ascii=False, sort_keys=True) + '\n')
                writer.flush()
                os.fsync(writer.fileno())
            self.previous = item['hash']
            return item

    def verify(self, max_events: int = 30) -> dict:
        previous = '0'*64
        count = 0
        last: list[dict] = []
        if not self.path.exists():
            return {'valid': True, 'events': 0, 'recent': []}
        with self.lock, self.path.open(encoding='utf-8') as reader:
            for line in reader:
                if not line.strip():
                    continue
                try:
                    item = json.loads(line)
                    digest = item.pop('hash')
                except (json.JSONDecodeError,KeyError,TypeError):
                    return {'valid': False, 'events_before_error':count, 'recent':[]}
                if previous != item['previous'] or not hmac.compare_digest(digest, self._digest(item)):
                    return {'valid': False, 'events_before_error': count, 'recent': []}
                previous = digest
                item['hash'] = digest
                count += 1
                last.append({'timestamp': item['timestamp'], 'event': item['event'], 'workspace': item['workspace'], 'metadata': item['metadata'], 'hash': digest})
                if len(last)>max_events:
                    last.pop(0)
        return {'valid': True, 'events': count, 'recent': last}
