"""Optional paired PC executor; never runs arbitrary commands from the gateway.

Start as an approved local service, with a *worker* token distinct from the MCP
ChatGPT token. The gateway can dispatch only tree/read/search/git status and
fixed locally configured checks.
"""
from __future__ import annotations
import asyncio
import json
import os
import sys
from pathlib import Path
from urllib.parse import urlsplit
import httpx
from .inspector import tree, read_file, find_text, git_read
from .runner import run_check_sequence

async def process_job(job:dict,workspaces:dict[str,Path],checks:dict)->dict:
    w=job.get('workspace')
    if w not in workspaces:return {'error':'Workspace non autorizzato sul PC'}
    root=workspaces[w]
    if not root.is_dir():return {'error':'Directory locale non disponibile'}
    op=job.get('operation')
    try:
        if op=='tree':return tree(root)
        if op=='read':return read_file(root,job.get('path',''))
        if op=='search':return find_text(root,job.get('query',''))
        if op=='git_status':return await git_read(root,'status')
        if op=='checks':
            if not checks.get(w):return {'error':'Nessun check autorizzato sul PC'}
            rows,ok=await run_check_sequence(root,checks[w])
            return {'outcome':'passed' if ok else 'failed','checks':rows}
        return {'error':'Operazione non consentita'}
    except (ValueError,OSError,RuntimeError,PermissionError) as exc:
        return {'error':f'{type(exc).__name__}: {str(exc)[:220]}'}

async def serve():
    url=os.getenv('KAIROS_GATEWAY_URL','').rstrip('/')
    u=urlsplit(url)
    if u.scheme!='https' and not (u.scheme=='http' and u.hostname in ('localhost','127.0.0.1')):
        raise ValueError('Il worker richiede HTTPS, eccetto test loopback')
    token=os.getenv('KAIROS_WORKER_TOKEN','')
    worker=os.getenv('KAIROS_WORKER_ID','')
    if len(token)<32 or not worker:raise ValueError('Credenziali worker mancanti o insufficienti')
    raw=json.loads(os.getenv('KAIROS_LOCAL_WORKSPACES','{}'))
    if not isinstance(raw,dict) or not raw:raise ValueError('Nessun workspace locale autorizzato')
    roots={a:Path(p).expanduser().resolve() for a,p in raw.items()}
    checks=json.loads(os.getenv('KAIROS_LOCAL_CHECKS','{}'))
    headers={'Authorization':'Bearer '+token}
    async with httpx.AsyncClient(timeout=25.0,headers=headers) as client:
        while True:
            try:
                resp=await client.post(url+'/worker/claim',json={'worker':worker})
                resp.raise_for_status()
                task=resp.json().get('job')
                if task:
                    result=await process_job(task,roots,checks)
                    # Avoid producing arbitrarily large upload bodies.
                    if len(json.dumps(result,ensure_ascii=False))>28_000:
                        result={'error':'Output troppo lungo; richiedere un estratto'}
                    report=await client.post(url+'/worker/complete',json={'worker':worker,'job_id':task['id'],
                        'lease_token':task['lease_token'],'result':result})
                    report.raise_for_status()
                else:
                    await asyncio.sleep(7)
            except (httpx.HTTPError,ValueError) as e:
                print('Gateway non disponibile:',type(e).__name__,file=sys.stderr)
                await asyncio.sleep(15)

if __name__=='__main__':
    asyncio.run(serve())
