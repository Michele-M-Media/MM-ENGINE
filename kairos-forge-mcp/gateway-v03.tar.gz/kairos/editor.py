"""Safe human-approved staging of ORIGINAL Kairos-generated code changes."""
from __future__ import annotations
import asyncio, json, os
from pathlib import Path
from uuid import uuid4
from .workspace import safe_path, sha, diff

MAX_FILE_BYTES = 110_000

class ChangeEngine:
    def __init__(self, council, checks: dict[str,list[list[str]]] | None = None):
        self.council = council
        self.checks = checks or {}
        self.lock = asyncio.Lock()
        self.stage_dir = council.state_dir / 'stages'
        self.stage_dir.mkdir(parents=True, exist_ok=True)

    def _stage_path(self, stage_id):
        if len(stage_id)!=32 or any(x not in '0123456789abcdef' for x in stage_id):
            raise ValueError('Stage ID non valido')
        return self.stage_dir / (stage_id + '.json')

    def _read(self, stage_id):
        try: return json.loads(self._stage_path(stage_id).read_text(encoding='utf-8'))
        except FileNotFoundError: raise ValueError('Stage inesistente') from None

    def _save(self, doc):
        p = self._stage_path(doc['id']); tmp=p.with_suffix('.tmp')
        tmp.write_text(json.dumps(doc, ensure_ascii=False,indent=2), encoding='utf-8')
        os.replace(tmp,p)

    async def propose(self, job_id: str, rel: str, instruction: str) -> dict:
        job = self.council.get(job_id)
        if job['status'] != 'approved_plan' or not job.get('approval', {}).get('approved'):
            raise PermissionError('Prima approvare il piano raggiunto dal council')
        root = self.council.workspaces[job['workspace']]
        p = safe_path(root, rel)
        before = p.read_text(encoding='utf-8') if p.exists() else ''
        if len(before.encode()) > MAX_FILE_BYTES: raise ValueError('File troppo grande')
        if len(instruction)>3500: raise ValueError('Istruzione troppo lunga')
        agent = 'developer'
        if not await self.council.backend.available(agent):
            raise RuntimeError('Kairos Developer non disponibile')
        prompt = f'''Sei Kairos Developer. Un piano e stato gia approvato da un utente.
TASK: {job['task']}
PIANO CONSENSUALE (DATO): {job['decision']['rationale'][:8000]}
FILE: {rel}
SHA256: {sha(before)}
CONTENUTO ATTUALE:\n{before[:MAX_FILE_BYTES]}
ISTRUZIONI SPECIFICHE: {instruction}
Rispondi SOLO con JSON valido: {{"content":"CONTENUTO COMPLETO NUOVO DEL FILE"}}.
Non usare segnaposto o cancellare codice estraneo.'''
        raw = await self.council.backend.ask(agent, prompt, root)
        try:
            obj = json.loads(raw.strip())
            content=obj['content']
            if not isinstance(content,str): raise ValueError('content deve essere stringa')
        except (json.JSONDecodeError,KeyError,TypeError,ValueError):
            raise ValueError('Kairos Developer non ha fornito JSON valido; nessuna modifica applicata') from None
        if len(content.encode())>MAX_FILE_BYTES:
            raise ValueError('Patch troppo grande')
        stage = {'id':uuid4().hex,'job_id':job_id,'workspace':job['workspace'],'path':rel,
                 'old_sha':sha(before),'new_sha':sha(content),'content':content,
                 'diff':diff(before,content,rel),'approved':False,'applied':False}
        if stage['old_sha']==stage['new_sha']: raise ValueError('Nessuna differenza da proporre')
        self._save(stage)
        return {k:stage[k] for k in ('id','job_id','path','diff','old_sha','new_sha','approved')}

    def stage_from_chat(self, workspace: str, rel: str, content: str) -> dict:
        """Stage code authored by the ChatGPT host (zero external inference).

        This is NOT an independent agent-generated proposal; provenance is
        explicit in the stage record and two-step user approval is required.
        """
        if workspace not in self.council.workspaces:
            raise ValueError('Workspace non autorizzato')
        if not isinstance(content,str) or len(content.encode()) > MAX_FILE_BYTES:
            raise ValueError('Contenuto non valido o troppo grande')
        root=self.council.workspaces[workspace]
        p=safe_path(root,rel)
        before=p.read_text(encoding='utf-8') if p.exists() else ''
        if len(before.encode())>MAX_FILE_BYTES:
            raise ValueError('File troppo grande')
        if sha(before)==sha(content):
            raise ValueError('Nessuna modifica')
        stage={'id':uuid4().hex,'job_id':None,'workspace':workspace,'path':rel,
               'old_sha':sha(before),'new_sha':sha(content),'content':content,
               'diff':diff(before,content,rel),'approved':False,'applied':False,
               'author':'chatgpt_host', 'independent_model_used':False}
        self._save(stage)
        return {k:stage[k] for k in ('id','path','diff','old_sha','new_sha','approved','author')}

    def preview(self, stage_id: str) -> dict:
        stage=self._read(stage_id)
        return {k:stage[k] for k in ('id','job_id','path','diff','old_sha','new_sha','approved','applied')}

    def approve(self, stage_id: str, approved: bool) -> dict:
        stage=self._read(stage_id)
        if stage['applied']: raise ValueError('Patch gia applicata')
        if not approved: stage['approved']=False
        else: stage['approved']=True
        self._save(stage)
        return {'id':stage_id,'approved':stage['approved'], 'notice':'Consenso registrato; file non ancora modificato.'}

    async def apply(self, stage_id: str) -> dict:
        async with self.lock:
            stage = self._read(stage_id)
            if not stage['approved'] or stage['applied']:
                raise PermissionError('Patch non approvata o gia applicata')
            root=self.council.workspaces[stage['workspace']]
            target=safe_path(root,stage['path'])
            before=target.read_text(encoding='utf-8') if target.exists() else ''
            if sha(before)!=stage['old_sha']:
                raise RuntimeError('Il file e cambiato dopo la proposta: niente overwrite')
            target.parent.mkdir(parents=True, exist_ok=True)
            backup=target.exists(); tmp=target.with_name(target.name+'.kairos-'+stage['id']+'.tmp')
            tmp.write_text(stage['content'],encoding='utf-8')
            os.replace(tmp,target)
            results=[]; ok=True
            for args in self.checks.get(stage['workspace'], []):
                # Test definitions are only accepted from server admin config.
                if not isinstance(args,list) or not args or not all(isinstance(a,str) for a in args):
                    continue
                try:
                    proc=await asyncio.create_subprocess_exec(*args,cwd=root,
                           stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
                    try: stdout,_=await asyncio.wait_for(proc.communicate(),timeout=75)
                    except asyncio.TimeoutError:
                        proc.kill();await proc.wait(); stdout=b'Timeout'; ok=False
                    rc=proc.returncode
                    results.append({'command':args,'exit_code':rc,'output':stdout.decode(errors='replace')[-2500:]})
                    if rc!=0: ok=False
                except Exception as exc:
                    results.append({'command':args,'error':str(exc)[:200]});ok=False
            if not ok:
                if backup:
                    temp_revert=target.with_name(target.name+'.kairos-restore.tmp')
                    temp_revert.write_text(before,encoding='utf-8');os.replace(temp_revert,target)
                else: target.unlink()
                return {'status':'rolled_back','stage_id':stage_id,'checks':results}
            stage['applied']=True;self._save(stage)
            return {'status':'applied','stage_id':stage_id,'path':stage['path'],
                    'checks':results,'verification':'NO_CHECK_CONFIGURED' if not results else 'CHECKS_PASSED'}
