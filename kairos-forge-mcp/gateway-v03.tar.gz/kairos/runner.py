"""Administrative, fixed-command checks with durable job status and cancellation.

Never accepts arbitrary shell commands from the MCP caller. Each command is
configured locally by the owner. No network calls or inference APIs.
"""
from __future__ import annotations
import asyncio
import json
import os
import signal
from pathlib import Path
from uuid import uuid4
from .audit import AuditLog

MAX_LOG = 9_000

async def run_check_sequence(root: Path, commands: list[list[str]], *, timeout: int = 60):
    results=[]
    for argv in commands:
        if (not isinstance(argv,list) or len(argv)>16 or not argv or
                not all(isinstance(a,str) and 0<len(a)<=500 for a in argv)):
            raise ValueError('Configurazione comando non valida')
        process=None
        try:
            # No shell, no caller-provided command. kill process group on timeout.
            process=await asyncio.create_subprocess_exec(*argv,cwd=root,
                stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT,
                start_new_session=(os.name=='posix'))
            try:
                stdout,_=await asyncio.wait_for(process.communicate(), timeout=timeout)
            except asyncio.TimeoutError:
                await _terminate(process)
                results.append({'command':argv,'exit_code':None,'status':'timeout','output':'Timed out'})
                return results,False
            output=stdout.decode('utf-8','replace')[-MAX_LOG:]
            results.append({'command':argv,'exit_code':process.returncode,'status':'pass' if process.returncode==0 else 'fail','output':output})
            if process.returncode!=0:
                return results,False
        except asyncio.CancelledError:
            if process and process.returncode is None:
                await _terminate(process)
            raise
        except OSError as ex:
            results.append({'command':argv,'exit_code':None,'status':'error','output':f'{type(ex).__name__}: {str(ex)[:250]}'})
            return results,False
    return results,True


async def _terminate(process):
    try:
        if os.name == 'posix': os.killpg(process.pid,signal.SIGKILL)
        else: process.kill()
    except ProcessLookupError:pass
    await process.wait()


class CheckQueue:
    def __init__(self, workspaces:dict[str,Path], checks:dict, state_dir:Path, audit:AuditLog):
        self.workspaces=workspaces
        self.checks=checks
        self.audit=audit
        self.root=state_dir/'checks'
        self.root.mkdir(parents=True,exist_ok=True)
        self.tasks:dict[str,asyncio.Task]={}
        self.sem=asyncio.Semaphore(2)
        for path in self.root.glob('*.json'):
            try:
                data=json.loads(path.read_text())
                if data.get('status') in ('queued','running'):
                    data['status']='interrupted'; self._save(data)
            except (OSError,ValueError,KeyError):pass

    def _path(self,job:str)->Path:
        if len(job)!=32 or any(x not in '0123456789abcdef' for x in job):raise ValueError('Job ID non valido')
        return self.root/(job+'.json')

    def _save(self,data:dict):
        p=self._path(data['id']);tmp=p.with_suffix('.tmp')
        tmp.write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8');os.replace(tmp,p)

    def get(self,job:str)->dict:
        try:return json.loads(self._path(job).read_text(encoding='utf-8'))
        except FileNotFoundError:raise ValueError('Job non trovato') from None

    def start(self, workspace:str)->dict:
        if workspace not in self.workspaces:raise ValueError('Workspace non autorizzato')
        cmds=self.checks.get(workspace,[])
        if not cmds:raise ValueError('Nessun check preconfigurato per il workspace')
        job=uuid4().hex
        data={'id':job,'workspace':workspace,'status':'queued','results':[]}
        self._save(data)
        self.audit.record('checks_queued',workspace=workspace,job_id=job)
        self.tasks[job]=asyncio.create_task(self._run(job))
        return {'id':job,'status':'queued','note':'Solo check preconfigurati, nessun comando shell dal client'}

    async def _run(self,job):
        data=self.get(job)
        try:
            async with self.sem:
                data['status']='running'; self._save(data)
                result,ok=await run_check_sequence(self.workspaces[data['workspace']],self.checks[data['workspace']])
                data['results']=result;data['status']='passed' if ok else 'failed';self._save(data)
                self.audit.record('checks_finished',workspace=data['workspace'],job_id=job,status=data['status'],steps=len(result))
        except asyncio.CancelledError:
            data['status']='cancelled';self._save(data)
            self.audit.record('checks_cancelled',workspace=data['workspace'],job_id=job)
            raise
        except Exception as exc:
            data['status']='failed';data['error']=f'{type(exc).__name__}: {str(exc)[:200]}';self._save(data)

    def cancel(self,job):
        data=self.get(job)
        if data['status'] not in ('running','queued'):return {'id':job,'status':data['status']}
        data['status']='cancelled';self._save(data)
        task=self.tasks.get(job)
        if task and not task.done():task.cancel()
        return {'id':job,'status':'cancelled'}
