"""Original Kairos roles and strictly zero-metered Ollama model adapter.

No invocation of Claude Code, Codex, OpenCode, Work, or external paid APIs.
"""
from __future__ import annotations
import asyncio
import json
import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

ROLES = {
    'architect': 'Sei Kairos Architect. Progetta la soluzione minima compatibile, analizza contratti/API e rischi. Non affermare di avere eseguito test.',
    'developer': 'Sei Kairos Developer. Sviluppa implementazioni concrete sui file realmente letti, preserva comportamento e proponi patch complete. Non modificare file in questa fase.',
    'verifier': 'Sei Kairos Verifier. Critica la soluzione, cerca bug, regressioni, vulnerabilita e test discriminanti. Non dichiarare PASS senza log reali.',
}

@dataclass(frozen=True)
class RoleInfo:
    name: str
    underlying_model: str
    inference: str

class OllamaBackend:
    """All roles can use one local/free model; role separation != independent models.

    Strict loopback target prevents MCP tool input from converting this adapter
    into an outbound request primitive. Model is selected by server admin only.
    """
    agent_names = list(ROLES)
    def __init__(self, model: str, url: str = 'http://127.0.0.1:11434', timeout: int = 120):
        self.model = model
        self.url = url.rstrip('/')
        self.timeout = timeout
        u = urlsplit(self.url)
        if not (u.scheme == 'http' and u.hostname in ('127.0.0.1','localhost','::1')
                and u.path in ('','/') and not u.username and not u.password
                and not u.query and not u.fragment):
            raise ValueError('Ollama accessibile solo tramite loopback del runner.')
        if not model or len(model) > 120:
            raise ValueError('Modello Ollama non valido.')
    def _request(self, path: str, payload: dict | None = None):
        raw = None if payload is None else json.dumps(payload).encode()
        req = Request(self.url + path, data=raw, headers={'Content-Type':'application/json'},
                      method='POST' if raw is not None else 'GET')
        with urlopen(req, timeout=self.timeout) as resp:
            return json.loads(resp.read(250_000))
    async def available(self, name: str) -> bool:
        if name not in ROLES:
            return False
        try:
            docs = await asyncio.to_thread(self._request, '/api/tags')
            return any(self.model in (x.get('model'), x.get('name')) for x in docs.get('models', []))
        except (OSError, ValueError, KeyError):
            return False
    async def ask(self, name: str, prompt: str, workspace: Path) -> str:
        if name not in ROLES:
            raise ValueError('Ruolo sconosciuto')
        msg = ROLES[name] + '\n\n' + prompt
        result = await asyncio.to_thread(self._request, '/api/generate', {
            'model': self.model, 'prompt': msg, 'stream': False,
            'options': {'temperature': 0.2, 'num_predict': 2100},
        })
        reply = result.get('response')
        if not isinstance(reply, str) or not reply.strip():
            raise ValueError('Nessuna risposta valida dal modello locale')
        return reply

class DisabledBackend:
    """No model installed: fail closed instead of making a metered request."""
    agent_names = list(ROLES)
    async def available(self, name: str) -> bool:
        return False
    async def ask(self, name: str, prompt: str, workspace: Path) -> str:
        raise RuntimeError('Nessun modello gratuito configurato')

def backend_from_env():
    # Explicitly no fallback to external APIs or Anthropic/OpenAI CLI.
    model = os.getenv('KAIROS_OLLAMA_MODEL', '').strip()
    if not model:
        return DisabledBackend()
    return OllamaBackend(model, os.getenv('KAIROS_OLLAMA_URL', 'http://127.0.0.1:11434'))
