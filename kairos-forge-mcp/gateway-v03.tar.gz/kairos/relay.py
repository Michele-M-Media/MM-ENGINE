"""Persistent gateway queue for a paired owner's desktop worker.

Jobs contain only predetermined operations. They never contain raw shell
commands. No write access is delegated by this MVP relay.
"""
from __future__ import annotations
import json
import os
import secrets
import threading
import time
from pathlib import Path
from uuid import uuid4
from .audit import AuditLog

OPERATIONS={'tree','git_status','checks','read','search'}
CLAIM_SECONDS=180

class Relay:
    def __init__(self,root:Path,workers:dict[str,list[str]],audit:AuditLog):
        self.root=root/'relay';self.root.mkdir(parents=True,exist_ok=True)
        self.workers=workers
        self.audit=audit
        self.lock=threading.Lock()
        self.online:dict[str,float]={}

    def _path(self,job_id:str)->Path:
        if len(job_id)!=32 or any(c not in '0123456789abcdef' for c in job_id):raise ValueError('ID relay non valido')
        return self.root/(job_id+'.json')

    def _save(self,doc):
        target=self._path(doc['id'])
        temp=target.with_suffix('.tmp')
        temp.write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(temp,target)

    def _get(self,jid):
        try:return json.loads(self._path(jid).read_text(encoding='utf-8'))
        except FileNotFoundError:raise ValueError('Job relay inesistente') from None

    def enqueue(self,worker:str,workspace:str,operation:str,path:str='',query:str='')->dict:
        if worker not in self.workers or workspace not in self.workers[worker]:
            raise PermissionError('Worker/workspace non autorizzato sul gateway')
        if operation not in OPERATIONS:raise ValueError('Operazione non supportata')
        if len(path)>240 or '..' in Path(path).parts or path.startswith(('/','\\')) or '\\' in path:
            raise ValueError('Percorso non valido')
        if operation=='read' and not path:raise ValueError('read richiede path')
        if operation=='search' and not 2<=len(query)<=100:raise ValueError('search richiede query')
        jid=uuid4().hex
        doc={'id':jid,'worker':worker,'workspace':workspace,'operation':operation,
             'path':path,'query':query,'status':'queued','created_at':time.time(),
             'lease_until':0,'lease_token':None,'attempts':0,'result':None}
        with self.lock:self._save(doc)
        self.audit.record('relay_enqueued',workspace=workspace,worker=worker,job_id=jid,operation=operation)
        return {'id':jid,'worker':worker,'status':'queued','operation':operation}

    def claim(self,worker:str)->dict|None:
        if worker not in self.workers:raise PermissionError('Worker sconosciuto')
        with self.lock:
            self.online[worker]=time.time()
            for path in sorted(self.root.glob('*.json')):
                doc=json.loads(path.read_text(encoding='utf-8'))
                if doc['worker'] != worker:continue
                # At most 2 attempts; an abandoned lease is not silently trusted.
                if doc['status']=='leased' and doc['lease_until']<time.time():
                    if doc['attempts']>=2:
                        doc['status']='interrupted'; self._save(doc)
                    else:
                        doc['status']='queued';self._save(doc)
                if doc['status']!='queued':continue
                doc['status']='leased';doc['attempts']+=1
                doc['lease_token']=secrets.token_hex(16)
                doc['lease_until']=time.time()+CLAIM_SECONDS
                self._save(doc)
                return {k:doc[k] for k in ['id','workspace','operation','path','query','lease_token']}
        return None

    def complete(self,worker:str,job_id:str,lease_token:str,result:dict)->dict:
        if not isinstance(result,dict):raise ValueError('Il risultato deve essere un oggetto')
        if len(json.dumps(result,ensure_ascii=False))>30_000:
            raise ValueError('Risultato troppo grande')
        with self.lock:
            doc=self._get(job_id)
            if (doc['worker']!=worker or doc['status']!='leased' or
                not secrets.compare_digest(doc['lease_token'] or '',lease_token) or
                doc['lease_until']<time.time()):
                raise PermissionError('Lease scaduto o job non assegnato')
            doc['status']='completed';doc['result']=result;doc['lease_token']=None
            self._save(doc)
        self.audit.record('relay_completed',workspace=doc['workspace'],worker=worker,job_id=job_id)
        return {'id':job_id,'status':'completed'}

    def status(self,job_id:str)->dict:
        with self.lock:
            doc=self._get(job_id)
        return {k:doc[k] for k in ('id','worker','workspace','operation','status','attempts','result')}

    def heartbeat(self,worker:str)->dict:
        if worker not in self.workers:raise PermissionError('Worker sconosciuto')
        self.online[worker]=time.time()
        return {'worker':worker,'status':'online'}

    def workers_status(self)->list[dict]:
        return [{'worker':worker,'allowed_workspaces':aliases,
                 'online':time.time()-self.online.get(worker,0)<45} for worker,aliases in self.workers.items()]
