"""Original independent deterministic reviewers, no tokens or models required."""
from __future__ import annotations
import ast, asyncio, json, re
from collections import Counter
from pathlib import Path
from .workspace import CODE_SUFFIXES, SKIP_DIRS, safe_path

MAX_SCAN_FILES=100

def files_to_scan(root):
    out=[]
    for p in sorted(root.rglob('*')):
        if len(out)>=MAX_SCAN_FILES: break
        if not p.is_file() or p.is_symlink() or p.suffix.lower() not in CODE_SUFFIXES or p.stat().st_size>80_000: continue
        rel=p.relative_to(root)
        if any(part.startswith('.') or part in SKIP_DIRS for part in rel.parts): continue
        try: safe_path(root,rel.as_posix())
        except ValueError: continue
        out.append(p)
    return out

async def review_architecture(root:Path):
    def run():
        files=files_to_scan(root)
        languages=Counter(x.suffix.lower() for x in files)
        important=[str(x.relative_to(root)) for x in files if x.name in ('pyproject.toml','package.json','Cargo.toml','go.mod','README.md')]
        return {'agent':'kairos-architect-static','files_scanned':len(files), 'language_exts':dict(languages),'manifests':important,
                'notes':['Analisi strutturale deterministica, non pianificazione semantica.']}
    return await asyncio.to_thread(run)

async def review_source(root:Path):
    def run():
        issues=[]; parsed=0
        for p in files_to_scan(root):
            if p.suffix.lower()!='.py':continue
            rel=p.relative_to(root).as_posix()
            try:
                ast.parse(p.read_text(encoding='utf-8'),filename=rel)
                parsed+=1
            except SyntaxError as e:
                issues.append({'file':rel,'line':e.lineno,'kind':'syntax_error','message':e.msg})
            except UnicodeDecodeError:
                issues.append({'file':rel,'kind':'decode_error'})
        return {'agent':'kairos-developer-static','parsed_python_files':parsed,'issues':issues[:30]}
    return await asyncio.to_thread(run)

async def review_risks(root:Path):
    def run():
        findings=[]
        patterns={'python_dynamic_exec':re.compile(r'\b(eval|exec)\s*\('),
                  'subprocess_shell':re.compile(r'shell\s*=\s*True'),
                  'http_unencrypted':re.compile(r'http://(?!localhost|127\.0\.0\.1)')}
        for p in files_to_scan(root):
            try: lines=p.read_text(encoding='utf-8').splitlines()
            except UnicodeDecodeError:continue
            for i,line in enumerate(lines[:2500],1):
                for kind,reg in patterns.items():
                    if reg.search(line):
                        findings.append({'file':p.relative_to(root).as_posix(),'line':i,'rule':kind,
                                         'severity':'review', 'note':'Indicatore da valutare; non prova di vulnerabilita'})
                        if len(findings)>=50:break
                if len(findings)>=50:break
            if len(findings)>=50:break
        return {'agent':'kairos-verifier-static','findings':findings}
    return await asyncio.to_thread(run)

async def run_static_review(root:Path):
    results=await asyncio.gather(review_architecture(root),review_source(root),review_risks(root))
    blockers=results[1]['issues']
    return {'agents':results,'outcome':'syntax_blockers' if blockers else 'static_review_completed',
            'limitations':'Controlli statici deterministici, non un voto di 3 LLM e non una build/runtime testata.',
            'external_api_calls':0}
