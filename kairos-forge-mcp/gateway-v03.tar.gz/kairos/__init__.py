"""Kairos Forge: independent roles and a ChatGPT-facing MCP server."""
__version__ = '0.1.0'
