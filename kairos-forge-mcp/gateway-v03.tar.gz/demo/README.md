# Demo Kairos Forge MCP

Questa cartella è un progetto **dimostrativo**, senza file privati.

La chat collegata via MCP può:
- elencare i file e leggere `hello.py`;
- preparare una patch, richiedere approvazione ed applicarla;
- eseguire il check autorizzato `python -m py_compile hello.py`;
- annullare una patch precedente se non ci sono state altre modifiche.

Il filesystem dell'hosting gratuito può essere effimero: non salvare qui progetti importanti.
