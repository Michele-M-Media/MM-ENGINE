"""Workspace di collaudo per Kairos Forge. Nessun dato personale."""


def greeting(name: str = "Kairos") -> str:
    return f"Ciao, {name}!"


if __name__ == "__main__":
    print(greeting())
