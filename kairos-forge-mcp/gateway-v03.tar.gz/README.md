# Kairos Forge PRO MCP — v0.2.0

**Owned, original MCP backend for ChatGPT Web, not Claude Code/Codex wrappers.**

## State of the project (read first)

- **Implemented and locally tested:** HTTP JSON-RPC MCP gateway with Bearer guard, explicit read-only file tools, project search/tree, read-only Git, 3 deterministic static reviews, optional local Ollama roles with debate and vote, fixed pre-approved build/test commands, multi-file staged changes requiring explicit approval, conflict detection, test rollback, recovery of interrupted transactions, chained audit log, and a remote PC worker queue (read/check only).
- **Not yet connected:** a public or tunneled HTTPS deployment reachable by this account's ChatGPT Web. An MCP ZIP or a skills-only ChatGPT plugin **does not** deploy the service.
- **Not proven:** Claude Code/Codex comparative performance, actual independent multi-model intelligence, cloud inference without paid API, end-to-end editing from ChatGPT Web, or remote writing on a PC.

**Design rule:** every interaction comes from the ChatGPT conversation. After connecting the server, the chat itself chooses and invokes MCP tools. No separate Claude/Codex/Work client is required. It does not call any metered third-party model API.

## High-level architecture

```text
ChatGPT Web / mobile (host model, plan limits apply)
       |
       | authenticated MCP Streamable HTTP (/mcp)
       v
Kairos Forge PRO gateway
  - read/search/tree/review/Git
  - stage -> preview -> explicit approval -> apply/check -> rollback
  - original Kairos council: Architect/Developer/Verifier via local Ollama if installed
  - fixed checks, queue, audit, checkpointable files
  - remote job dispatcher -> PC worker (online only)
       |                           |
       v                           v
Server-approved cloud workspace    Worker-approved Windows/WSL/Linux workspace
```

## Demonstrable capabilities

| Layer | Tools | Guard |
| --- | --- | --- |
| Project | `kairos_tree`, `kairos_read`, `kairos_search`, `kairos_git`, `kairos_project` | Allowlisted workspaces, path traversal and secrets excluded, size caps |
| Code quality | `kairos_static_review`, `kairos_checks_start/get/cancel` | Static reviewers; only owner-configured commands |
| Editing | `kairos_batch_stage/preview/approve/apply/undo` | Multi-file diff, explicit approval phrase, optimistic SHA, one writer, automatic checks and rollback |
| Agent debate | `kairos_council_start/get/approve/cancel` | Three original prompts, peer review and vote; needs local Ollama model |
| Existing single-file editor | `kairos_patch_stage_from_chat/preview/approve/apply`, `kairos_patch_propose` | Preserved for compatibility |
| Audit | `kairos_audit` | Hash chain, optional HMAC key in private environment |
| PC worker | `kairos_remote_workers/enqueue/status` | Authenticated PC worker, predefined read-only/check commands; no remote arbitrary shell |

## Quickstart: local test (requires Python 3.11+)

```bash
python -m pip install -r requirements.txt
export KAIROS_MCP_TOKEN="$(python -c 'import secrets; print(secrets.token_urlsafe(48))')"
export KAIROS_WORKSPACES='{"demo":"/absolute/path/to/a/project"}'
export KAIROS_STATE_DIR='./private-state'
uvicorn kairos.server:app --host 127.0.0.1 --port 8000 --workers 1
```

A separate shell can invoke `python scripts/smoke_http.py --base http://127.0.0.1:8000 --token "$KAIROS_MCP_TOKEN"` for a **local** protocol smoke test. Production requires HTTPS or a secure tunnel. Never expose the server without authentication.

## Making ChatGPT Web actually call it

1. Host this server on your own computer with an authorized Secure MCP Tunnel or on a cloud host with **public HTTPS `/mcp`**. The HTTP server must be reachable and have a supported authentication setup; bearer-only here is an MVP, not a validated OAuth implementation.
2. Add the server via **ChatGPT → Plugins → Add custom MCP server**, if your account/workspace allows it. Use the real endpoint, not a made-up example. Review the tool list and permissions. The custom-plugin flow and supported Chat/Work surfaces can vary by account.
3. Test from a new chat: `@Kairos ... kairos_status`, `kairos_tree`, `kairos_batch_stage` and a read-only Git request. Verify the returned tool data. Only after these tests consider write operations.
4. For an always-on cloud worker when PC is off, the host must genuinely support persistence and build dependencies; free tiers usually have quotas/sleep and no free unlimited GPU. Do **not** activate a paid hosting plan or paid inference without permission.

Official reference: https://developers.openai.com/plugins/deploy/connect-chatgpt

## Pair a PC (optional; no original Codex/Claude process)

Gateway owner configuration (in private environment, not committed):

```text
KAIROS_REMOTE_WORKERS={"home-pc":["myproject"]}
KAIROS_WORKER_TOKEN=<separate-long-random-worker-token>
```

On the **authorized** Windows/WSL/Linux PC, install requirements and configure:

```text
KAIROS_GATEWAY_URL=https://<YOUR-ACTUAL-PRIVATE-GATEWAY>
KAIROS_WORKER_ID=home-pc
KAIROS_WORKER_TOKEN=<same-secret-as-gateway>
KAIROS_LOCAL_WORKSPACES={"myproject":"/path/to/authorized/project"}
KAIROS_LOCAL_CHECKS={"myproject":[["python","-m","pytest","-q"]]}
```

Run `python -m kairos.remote_worker` under an owner-authorized background service. This worker **pulls** safe tasks, runs predefined checks, and reports back to the gateway. It does not expose a public inbound port and it does not execute arbitrary user-supplied shell commands. When the PC is offline, the gateway cannot access its files. Remote code editing is not implemented in this version; cloud-hosted code changes are possible in server-authorized workspaces.

## Tests and limitations

Run `PYTHONPATH=. python -m pytest -q tests`. Tests are self-contained: they use temporary repositories, real local file writes, real subprocess checks and local HTTP ASGI requests. Mocked Ollama roles are **not** proof of model intelligence. The full official MCP SDK/client handshake and real ChatGPT Web pairing remain untested until dependencies, hosting and permissions are available.

- The gateway uses one Uvicorn worker; no cross-process locking is provided yet.
- A cloud free plan without persistent storage can lose state and projects on redeploy/sleep.
- Audit logs contain metadata and hashes, not source code; `KAIROS_AUDIT_KEY` should be set in production to make the chain tamper-evident.
- Staged file contents remain on the server's own filesystem; apply filesystem permissions and encryption where warranted.
- Security reviews, OAuth 2.1, multi-user isolation, distributed locking, retries, monitoring and independent benchmark results are needed before claiming a commercial PRO-level service.
- Read-only PC worker is a beta; no remote arbitrary shell or uncontrolled write allowed.

## Privacy and cost

No Claude/Codex/OpenCode/Work CLI is used. No requests to paid Anthropic/OpenAI APIs are made. Ollama is loopback-only and optional. ChatGPT remains subject to the user's plan limits; cloud runtime and GPU are not guaranteed unlimited for free. This code can be privately hosted and controlled by the owner.
