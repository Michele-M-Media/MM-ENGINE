# Kairos Forge — deploy privato per ChatGPT Web

L'obiettivo è connettere **questo esatto server** a ChatGPT Web come plugin MCP personale.
Non installa né richiama Claude Code, Codex o OpenCode. Non effettua API AI a consumo.

## Requisiti verificabili

1. Un hosting HTTPS con runtime Python e sorgenti del progetto.
2. `KAIROS_MCP_TOKEN`: segreto casuale lungo almeno 32 caratteri, **mai nel repo**.
3. `KAIROS_WORKSPACES`: alias > path autorizzato; per la prima prova solo `demo`.
4. `KAIROS_STATE_DIR`: cartella privata scrivibile; su hosting free potrebbe essere effimera.
5. Plugin ChatGPT con `mcp.json`, server `type: streamable-http`, URL HTTPS `/mcp`, auth `api_key` con `headerScheme: bearer`.

## Primo test end-to-end da ChatGPT Web

- Leggi lo stato: `kairos_status`.
- Esplora la demo: `kairos_tree {workspace:"demo"}`.
- Leggi `hello.py` con `kairos_read`.
- Proponi una modifica con `kairos_batch_stage`; leggi diff via `kairos_batch_preview`.
- Solo dopo conferma esplicita dell'utente, usa `kairos_batch_approve` e `kairos_batch_apply`.
- Verifica il codice con `kairos_checks_start` / `kairos_checks_get`; riferisci exit code reale.

## Attenzione

- La demo cloud gratuita non è un deposito permanente del codice: se il servizio entra in sleep o riavvia, i file non salvati altrove possono scomparire.
- L'accesso al PC personale richiede il worker remoto autorizzato online. Non è automatico.
- Il token può richiedere una connessione una tantum all'interno della UI Plugin di ChatGPT.
- Verificare eventuali limiti di banda del provider. Non attivare piani a pagamento o modelli con fatturazione.
