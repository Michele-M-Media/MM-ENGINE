"""Bounded, no-billing native task routing and static tools for Kairos.

This module does not load an LLM, execute any AITMPL content, run code, open
user files, or call a commercial API. Catalog text is UNTRUSTED task data.
"""
from __future__ import annotations

import ast
from collections import Counter
from difflib import unified_diff
from hashlib import sha256
import json
import re
import tomllib
import xml.etree.ElementTree as ET

from native_registry import NativeRegistry, TEXT_PROFILE_TYPES, UNTRUSTED_NOTICE, _summary

MAX_TASK = 360
MAX_SOURCE = 16_000
ALLOWLIST_LICENSES = {"mit", "apache-2.0", "bsd-2-clause", "bsd-3-clause", "isc", "cc0-1.0", "unlicense"}
BLOCK_SEVERITIES = {"high", "critical", "severe", "malicious"}
ITALIAN_TO_ENGLISH = {
    "errori": "errors", "errore": "error", "correggi": "fix", "correzione": "fix",
    "debugging": "debugging", "analizza": "analysis", "analisi": "analysis", "sicurezza": "security",
    "testare": "test", "test": "test", "revisione": "review", "ottimizza": "optimization",
    "ottimizzazione": "optimization", "compilazione": "build", "compilare": "build",
    "architettura": "architecture", "documentazione": "documentation", "progetto": "project",
}
COMMON_TERMS = {"the", "and", "with", "from", "for", "per", "con", "una", "uno", "nel", "nella", "della", "degli", "deve", "fare", "questo", "codice", "code", "project", "progetto", "software", "crea", "create", "sul", "del", "all", "tutti"}


def terms(task: str) -> tuple[str, ...]:
    if not isinstance(task, str) or not task.strip() or len(task) > MAX_TASK or "\x00" in task:
        raise ValueError("Task must be a nonempty string up to 360 characters")
    tokens = re.findall(r"[\w.+-]{2,}", task.casefold())
    normalized = []
    for token in tokens:
        if token not in COMMON_TERMS:
            normalized.append(token)
            if token in ITALIAN_TO_ENGLISH:
                normalized.append(ITALIAN_TO_ENGLISH[token])
    return tuple(dict.fromkeys(normalized))[:16]


def _ranking(registry: NativeRegistry, task: str) -> list[tuple[int, str]]:
    candidates = []
    tokens = terms(task)
    if not tokens:
        return []
    for cid, item in registry.refresh().items.items():
        if item["type"] not in TEXT_PROFILE_TYPES:
            continue
        name = str(item.get("name") or "").casefold()
        cat = str(item.get("category") or "").casefold()
        desc = str(item.get("description") or "").casefold()
        slug = cid.casefold()
        score = 0
        for token in tokens:
            if token in name:
                score += 10
            elif token in cat:
                score += 6
            elif token in desc:
                score += 3
            elif token in slug:
                score += 2
        if score:
            score += {"skills": 4, "agents": 3, "commands": 2, "loops": 1}[item["type"]]
            candidates.append((score, cid))
    return sorted(candidates, key=lambda v: (-v[0], v[1]))


def select(registry: NativeRegistry, task: str, limit: int = 6) -> dict:
    if type(limit) is not int or not 1 <= limit <= 12:
        raise ValueError("limit must be between 1 and 12")
    ranked = _ranking(registry, task)
    state = registry.refresh()
    selected = []
    for score, cid in ranked[:limit]:
        item = state.items[cid]
        info = _summary(item)
        lic = str(item.get("license") or "").strip().casefold()
        scan = item.get("scan") if isinstance(item.get("scan"), dict) else {}
        severity = str(scan.get("severity") or "unknown").casefold()
        info.update({"relevance_score": score, "license_review_required": lic not in ALLOWLIST_LICENSES,
                     "security_review_required": severity in BLOCK_SEVERITIES or severity == "unknown",
                     "execution_state": "recipe-only-no-process-started"})
        selected.append(info)
    return {"task": task, "matches": len(ranked), "candidates": selected,
            "component_count": len(state.items), "registered_catalog_hash": state.fingerprint,
            "independent_models_started": 0, "third_party_code_executed": False,
            "model_api_charges": False, "note": UNTRUSTED_NOTICE}


def prepare_task(registry: NativeRegistry, task: str, limit: int = 3, max_chars_each: int = 2600) -> dict:
    if type(limit) is not int or not 1 <= limit <= 4:
        raise ValueError("limit must be 1–4")
    if type(max_chars_each) is not int or not 300 <= max_chars_each <= 3500:
        raise ValueError("max_chars_each must be 300–3500")
    ranked = _ranking(registry, task)
    state = registry.refresh()
    approved: list[dict] = []
    review_needed: list[dict] = []
    types_taken = Counter()
    # Try the best candidate in each native text category before filling remaining slots.
    first_by_type = {}
    for score, cid in ranked:
        typ = state.items[cid]['type']
        if typ not in first_by_type:
            first_by_type[typ] = (score, cid)
    prioritized = list(first_by_type.values()) + [row for row in ranked if row not in first_by_type.values()]
    attempts = 0
    for score, cid in prioritized:
        if len(approved) >= limit or attempts >= 24:
            break
        attempts += 1
        item = state.items[cid]
        typ = item["type"]
        # Diversify agent/skill/command suggestions, rather than repeated near-identical recipes.
        if types_taken[typ] >= 2:
            continue
        lic = str(item.get("license") or "").strip().lower()
        scan = item.get("scan") if isinstance(item.get("scan"), dict) else {}
        sev = str(scan.get("severity") or "unknown").lower()
        if lic not in ALLOWLIST_LICENSES or sev in BLOCK_SEVERITIES or sev == "unknown":
            review_needed.append({"id": cid, "license": item.get("license"), "scan_severity": sev,
                                  "reason": "License/security information needs human review"})
            continue
        try:
            result = registry.prepare(cid, max_chars=max_chars_each)
        except (ValueError, KeyError, RuntimeError, TimeoutError, OSError) as exc:
            review_needed.append({"id":cid, "reason":f"Source unavailable: {type(exc).__name__}"})
            continue
        if result.get("capability_state") != "text-recipe-prepared-not-executed":
            continue
        approved.append({"id": cid, "type": typ, "name": str(item.get("name") or "")[:120],
                         "license":item.get("license"), "score":score,
                         "recipe_text":result["text"], "text_sha256":result["source_content_sha256"],
                         "truncated":result["truncated"], "source_page":result["source_page"]})
        types_taken[typ] += 1
    return {"task":task, "selected": approved, "requires_review": review_needed[:8],
            "matched":len(ranked), "execution": "current-chat-model-only-no-untrusted-code-executed",
            "external_api_credits_used": False, "source_is_untrusted": True, "important":UNTRUSTED_NOTICE,
            "status": "ready-for-chat-assistant" if approved else "needs-source-or-review"}


def check_source(language: str, source: str) -> dict:
    if language not in ("python", "json", "toml", "xml"):
        raise ValueError("Unsupported language; use python/json/toml/xml")
    if not isinstance(source, str) or len(source) > MAX_SOURCE or "\x00" in source:
        raise ValueError("Invalid or oversized source")
    resp = {"language": language, "checked_bytes": len(source.encode("utf-8")),
            "stored": False, "executed": False, "external_api_used": False,
            "syntax_ok": True, "errors": [], "observations": []}
    try:
        if language == "python":
            parsed = ast.parse(source)
            functions, classes, imports = [], [], []
            risky = []
            for node in ast.walk(parsed):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    functions.append(node.name)
                elif isinstance(node, ast.ClassDef):
                    classes.append(node.name)
                elif isinstance(node, ast.Import):
                    imports += [n.name for n in node.names]
                elif isinstance(node, ast.ImportFrom) and node.module:
                    imports.append(node.module)
                elif isinstance(node, ast.Call):
                    f = node.func
                    if isinstance(f, ast.Name) and f.id in {"eval","exec","compile"}:
                        risky.append({"name": f.id, "line": node.lineno})
                    elif isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) and (f.value.id, f.attr) in {("os","system"),("subprocess","Popen"),("subprocess","run")}:
                        risky.append({"name": f.value.id+"."+f.attr, "line": node.lineno})
            resp["observations"] = [{"functions": functions[:60], "classes": classes[:40], "imports": sorted(set(imports))[:60], "risky_call_indicators": risky[:40]}]
        elif language == "json":
            root = json.loads(source)
            resp["observations"] = [{"root_type": type(root).__name__}]
        elif language == "toml":
            root = tomllib.loads(source)
            resp["observations"] = [{"top_level_keys": list(root)[:50]}]
        else:
            if "<!DOCTYPE" in source.upper() or "<!ENTITY" in source.upper():
                raise ValueError("DTD or XML entity declarations not supported")
            root = ET.fromstring(source)
            resp["observations"] = [{"root_tag": root.tag[:120]}]
    except (SyntaxError, ValueError, TypeError, RecursionError, ET.ParseError) as exc:
        resp["syntax_ok"] = False
        resp["errors"] = [{"kind": type(exc).__name__, "message": str(exc)[:350],
                           "line": getattr(exc, "lineno", None), "offset": getattr(exc, "offset", None)}]
    resp["note"] = "Parsing is not a compiler/build or a security guarantee. No source was run."
    return resp


def diff_preview(before: str, after: str, filename: str = "file.txt") -> dict:
    if any(not isinstance(v, str) or len(v) > 12_000 or "\x00" in v for v in (before, after)):
        raise ValueError("Invalid or oversized before/after text")
    if not isinstance(filename, str) or len(filename) > 120 or not re.fullmatch(r"[A-Za-z0-9_.-]+", filename):
        raise ValueError("Use a simple filename without directories")
    diff = list(unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True), fromfile="a/"+filename, tofile="b/"+filename, n=3))
    text = "".join(diff)
    added = sum(1 for line in diff[2:] if line.startswith("+") and not line.startswith("+++"))
    removed = sum(1 for line in diff[2:] if line.startswith("-") and not line.startswith("---"))
    return {"filename":filename, "changes": {"lines_added":added,"lines_removed":removed},
            "diff": text[:8000], "diff_truncated":len(text)>8000,
            "mutated_any_file":False,"paid_api_used":False}
