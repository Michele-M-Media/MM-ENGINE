import json
from starlette.testclient import TestClient
import gateway

def test_mcp_init_list_readonly():
 with TestClient(gateway.app) as c:
  r=c.post('/mcp',json={'jsonrpc':'2.0','id':1,'method':'initialize'})
  assert r.status_code==200
  assert r.json()['result']['serverInfo']['name']=='kairos-native-registry'
  r=c.post('/mcp',json={'jsonrpc':'2.0','id':2,'method':'tools/list'})
  assert len(r.json()['result']['tools'])==14
  assert all(t['annotations']['readOnlyHint'] for t in r.json()['result']['tools'])
  assert c.get('/health').json()['exposes_user_files'] is False

def test_search_and_detail(monkeypatch):
 corpus={'schemaVersion':'1.1.0','components':[{'id':'skills/dev/debugger','name':'debugger','type':'skills','license':'MIT','description':'Debug errors','urls':{}}]}
 monkeypatch.setattr(gateway,'fetch',lambda r,limit=gateway.MAX_SIZE:corpus)
 assert gateway.search('debug')['components'][0]['id']=='skills/dev/debugger'
 assert gateway.detail('skills/dev/debugger')['not_executable']

def test_validated_id_blocks_ssrf(monkeypatch):
 try: gateway.lookup('skills/../../../../etc')
 except ValueError:pass
 else:raise AssertionError('bad id was accepted')

def test_preview_is_text_only(monkeypatch):
 corpus={'schemaVersion':'1.1.0','components':[{'id':'skills/dev/debugger','name':'debugger','type':'skills','license':'MIT','description':'Debug errors','urls':{}}]}
 monkeypatch.setattr(gateway,'lookup',lambda cid: corpus['components'][0])
 monkeypatch.setattr(gateway,'fetch',lambda path,limit=gateway.MAX_SIZE:{'content':'# Debug instructions'})
 result=gateway.preview('skills/dev/debugger')
 assert result['not_executable'] and result['content_excerpt']=='# Debug instructions'
