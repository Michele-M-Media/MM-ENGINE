import json
import pytest
from starlette.testclient import TestClient

import gateway
from native_tasks import select, prepare_task, check_source, diff_preview
from native_registry import NativeRegistry


def build_registry(tmp_path):
    components = []
    for i in range(2000):
        kind = ('skills','agents','commands','loops','mcps','hooks','mods','settings')[i % 8]
        component_id=f'{kind}/kairos/sample-{i}'
        components.append({'id':component_id,'type':kind,'name':f'Debugging workflow {i}',
                           'category':'development','description':'find error debug tests review',
                           'license':'MIT','scan':{'severity':'LOW'},
                           'urls':{'content':f'https://www.aitmpl.com/component-content/{component_id}.json'}})
    payload={'schemaVersion':'1.0.0','count':len(components),'components':components}
    def fetch(path,limit=999999):
        if path=='api/v1/catalog.json':return payload
        if path.startswith('component-content/'):
            return {'content':'# Debugging workflow\n1. Examine test errors.\n2. Write a focused regression test.'}
        raise ValueError(path)
    return NativeRegistry(fetch, tmp_path/'snap.gz')


def test_task_router_all_types_are_indexed_and_text_only(tmp_path):
    registry=build_registry(tmp_path)
    result=select(registry,'Correggi errori debugging',limit=12)
    assert result['component_count']==2000
    assert result['matches']>100
    assert len(result['candidates'])==12
    assert {x['type'] for x in result['candidates']} <= {'skills','agents','commands','loops'}
    assert result['third_party_code_executed'] is False


def test_task_prepare_chooses_safe_content(tmp_path):
    registry=build_registry(tmp_path)
    plan=prepare_task(registry,'debug errors in project',limit=4)
    assert plan['status']=='ready-for-chat-assistant'
    assert len(plan['selected'])==4
    assert len({x['type'] for x in plan['selected']})>=2
    assert all(x['recipe_text'].startswith('# Debugging') for x in plan['selected'])
    assert plan['external_api_credits_used'] is False


def test_unreviewed_license_and_security_not_automatically_included(tmp_path):
    registry=build_registry(tmp_path)
    state=registry.refresh()
    for item in state.items.values():
        if item['type'] in ('skills','agents','commands','loops'):
            item['license']='unknown'
    plan=prepare_task(registry,'debug',limit=3)
    assert not plan['selected']
    assert plan['requires_review']
    assert plan['status']=='needs-source-or-review'


def test_task_inputs_bounded(tmp_path):
    reg=build_registry(tmp_path)
    for invalid in ('', ' ', 'X'*361):
        with pytest.raises(ValueError):select(reg,invalid)
    with pytest.raises(ValueError):prepare_task(reg,'debug',limit=9)


def test_static_check_python_does_not_run_code(tmp_path):
    target=tmp_path/'should-not-exist'
    source=f'open({str(target)!r}, "w").write("hi")\ndef hello():\n    return 2\n'
    report=check_source('python',source)
    assert report['syntax_ok'] and report['executed'] is False
    assert not target.exists()
    assert 'hello' in report['observations'][0]['functions']
    assert not check_source('python','def f(: pass')['syntax_ok']
    assert check_source('json','{"x": 1}')['syntax_ok']
    assert not check_source('json','{broken}')['syntax_ok']
    assert check_source('toml','a=1')['syntax_ok']
    assert check_source('xml','<root/>')['syntax_ok']
    with pytest.raises(ValueError):check_source('python','x'*17000)


def test_diff_preview_is_readonly():
    r=diff_preview('x=1\n','x=2\n',filename='hello.py')
    assert r['changes']=={'lines_added':1,'lines_removed':1}
    assert '-x=1' in r['diff'] and '+x=2' in r['diff']
    assert r['mutated_any_file'] is False
    with pytest.raises(ValueError):diff_preview('','',filename='../secret.py')


def test_mcp_wire_new_tools(monkeypatch,tmp_path):
    reg=build_registry(tmp_path)
    monkeypatch.setattr(gateway,'REGISTRY',reg)
    with TestClient(gateway.app) as client:
        tools=client.post('/mcp',json={'jsonrpc':'2.0','id':1,'method':'tools/list'}).json()['result']['tools']
        assert len(tools)==14
        for name,args in (
            ('kairos_task_route',{'task':'Debugging errors'}),
            ('kairos_task_prepare',{'task':'Debugging errors','limit':2}),
            ('kairos_code_static_check',{'language':'python','source':'x=2\n'}),
            ('kairos_diff_preview',{'before':'a','after':'b','filename':'sample.txt'})
        ):
            res=client.post('/mcp',json={'jsonrpc':'2.0','id':2,'method':'tools/call','params':{'name':name,'arguments':args}})
            assert res.status_code==200
            assert res.json()['result']['isError'] is False
            value=json.loads(res.json()['result']['content'][0]['text'])
            assert isinstance(value,dict)
        assert client.get('/health').json()['mcp_tools']==14
        denied=client.post('/mcp',headers={'Origin':'https://untrusted.invalid'},json={'jsonrpc':'2.0','id':9,'method':'tools/list'})
        assert denied.status_code==403
