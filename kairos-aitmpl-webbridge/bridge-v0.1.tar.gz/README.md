# Kairos Forge — Native AITMPL MCP v0.8

A private-account plugin can reference this **public, read-only** bridge to the complete AITMPL v1 catalog. The bridge is a source of untrusted public reference content, **not** a code executor or independent LLM. 8 catalog categories are indexed. Text recipes (agents, skills, commands, loops) may be selected and prepared for the ChatGPT host. Hooks, external MCPs, settings and mods remain descriptors until separate secure implementation.

## New native tasks (v0.8)

- `kairos_task_route(task, limit=6)` — select context recipes from the entire index for a natural-language coding task.
- `kairos_task_prepare(task, limit=3)` — fetch and assemble permissively licensed, low-severity recipe snippets (unknown license or scan status requires review). **The chat is the only reasoning model**; external instructions are untrusted data.
- `kairos_code_static_check(language, source)` — parse Python, JSON, TOML or XML **without running it**; a syntax check is not a build or full code security audit.
- `kairos_diff_preview(before, after, filename)` — show a patch in memory, **without modifying a workspace**.

The 10 existing AITMPL registry tools remain unchanged. Total **14 MCP read-only tools**.

## Safety/limits

No Claude, Codex, OpenCode CLI, purchased inference API, shell, persistent user workspace, access to private files, or desktop control is invoked. This public endpoint **must not** be given private source code/secrets. Local execution requires a **separate, authenticated** MCP with explicit permissions and project isolation. This server intentionally does not apply or execute downloaded AITMPL content. The external catalog can change, and the entire set is not locally installed.

For the hosted deployment, the existing Render free plan extracts the source archive and runs `uvicorn gateway:app`. The plugin must be selected and its MCP tools actually loaded by ChatGPT; a successful deployment does not prove invocation from the current conversation.

## Tests

`python -m pytest -q` covers a fake 2000-entry catalog, selection/diversity, licensing/security gates, static parsing without execution, in-memory diff, origin guard, and full JSON-RPC MCP tools/list and tools/call cycles. These are local tests and **not** live ChatGPT invocations.
