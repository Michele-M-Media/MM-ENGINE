# Kairos AITMPL WebBridge, test di connessione read-only

Un gateway MCP **solo in lettura** per verificare la prima chiamata live da ChatGPT Web. Espone soltanto `kairos_aitmpl_status`, `kairos_aitmpl_search`, `kairos_aitmpl_detail` e `kairos_aitmpl_preview`. Non possiede repo, credenziali, terminale o accesso ai file utente. Ecco perché può funzionare in modo pubblico senza segreti come primo smoke test; non sostituisce il server Kairos Forge privato.

`pip install -r requirements.txt` poi `uvicorn gateway:app --host 0.0.0.0 --port $PORT`.

Endpoint `/mcp` (Streamable HTTP JSON-RPC) e `/health`. Nessun software commerciale, nessun costo API aggiuntivo. Un hosting gratuito può sospenderlo e limitare l'uso.

**Non usare questo bridge per codice privato o azioni di scrittura**. Per quel caso è necessario il server completo dietro autenticazione e il supporto del piano ChatGPT alle azioni write di MCP.
