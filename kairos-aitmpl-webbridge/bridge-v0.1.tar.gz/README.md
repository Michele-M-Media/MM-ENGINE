# Kairos Forge MCP — v0.9 (2026 compatibility)

This is an isolated **public, read-only** gateway for the AITMPL catalog.
It is deployed on the existing Render free web service and is referenced by
Kairos Code Engineer's personal plugin. There is no paid model API, private
filesystem access, shell, external MCP execution or privileged worker on this
public endpoint.

## MCP transport

- HTTPS JSON-RPC over `/mcp` (POST).
- Backwards-compatible 2025-03-26, 2025-06-18 and 2025-11-25 handshakes.
- 2026-07-28 request metadata and mirrored headers are validated.
- Legacy GET/DELETE `/mcp` return `405 Method Not Allowed` without SSE.
- `kairos_server_diagnostics`: confirms server version, loaded catalog size,
  supported protocol versions, tool count, request counters and security mode.
- `GET /health`: safe public status without any user source or credentials.

## Running and testing

```bash
python -m pip install -r requirements.txt
python -m pytest -q # pytest and httpx are dev-only requirements
uvicorn gateway:app --host 127.0.0.1 --port 8000
```

The pre-existing catalog implements 8 typed categories. Text recipes are
untrusted; no third-party hook, shell or program is executed. A registered item
is **not** equivalent to a working standalone agent/process. Only select text
recipes needed for the current task to avoid overwhelming the model.

## Security and ChatGPT validation

The deployment can be healthy without ChatGPT having enabled this plugin. The
client must select/connect it and its MCP actions must be present in the ChatGPT
session. `kairos_server_diagnostics` reports real POSTs to MCP; it does not
claim whether the caller was ChatGPT. When testing, compare request counters
before/after, and verify the corresponding client-side tool invocation.

Do **not** send private code to this public bridge. Writable project tools
require a separately authenticated service with workspace isolation and
explicit approval; an anonymous shared endpoint must never host those tools.
