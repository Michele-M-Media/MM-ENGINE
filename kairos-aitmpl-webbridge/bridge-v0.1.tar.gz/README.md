# Kairos Forge — AITMPL Native Registry v0.7

This is a replacement for the original *read-only* AITMPL MCP gateway. It indexes **all entries in the official AITMPL v1 catalog** as first-class, typed Kairos capability descriptors: agents, commands, MCPs, settings, hooks, skills, loops and mods. It preserves the four original MCP tools and adds full registry/list/prepare/compose capabilities.

## What "native" means

- **All 8 types registered** from the official complete `/api/v1/catalog.json` feed, with ID, category, license, provenance, risk indicators and refresh/snapshot support.
- **Agents, skills, commands and loops**: usable as prompt recipes, prepared *on demand* with provenance and a safety boundary; no Claude Code installation.
- **MCP connectors, hooks, settings and mods**: registered and inspectable, **not executable** until a compatible implementation, credential and authorization exists.
- A selected template is **not an independently running model**. The chat LLM is still the reasoning engine. No paid model API calls.
- Catalog metadata and template instructions remain **untrusted**, subject to the user's permissions and application security policy.

## Deployment and limits

`uvicorn gateway:app --host 0.0.0.0 --port 10000`, or deploy the archive on the existing Render service. HTTPS termination provided by host.

MCP tools: `kairos_registry_status`, `kairos_registry_list`, `kairos_registry_search`, `kairos_registry_get`, `kairos_component_prepare`, `kairos_component_compose` plus original `kairos_aitmpl_*` tools. The new tools are read-only and safe to expose publicly. No filesystem, user data, shell or paid AI API calls are exposed.

The official feed's item count and types are **measured at runtime**. If upstream is unavailable and an old snapshot exists, status labels it stale; otherwise the server reports a failure. On a free ephemeral instance the snapshot may be lost between cold starts. `KAIROS_REGISTRY_SNAPSHOT` can select an on-disk gzip snapshot path (default `./registry-cache/catalog.json.gz`).

This gateway is separate from the writable Kairos Forge engine; it does not yet provide private PC control or execute AI models in cloud.
