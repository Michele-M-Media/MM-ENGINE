import copy
import json
import pytest
from starlette.testclient import TestClient
import gateway
from native_registry import NativeRegistry, TYPES


def fake_catalog(number=2000):
    components=[]
    for i in range(number):
        kind=TYPES[i%len(TYPES)]
        components.append({
            'id':f'{kind}/kairos/test-{i}',
            'type':kind,
            'name':f'test-{i}',
            'category':'kairos',
            'description':f'Catalog entry {i}, debugging tool',
            'license':'MIT',
            'urls':{'page':'https://www.aitmpl.com/component/example','content':'https://www.aitmpl.com/component-content/example.json'},
            'scan':{'severity':'LOW','score':0},
        })
    return {'schemaVersion':'1.0.0','count':len(components),'generatedAt':'2026-11-11T00:00:00Z','components':components}


@pytest.fixture
def registry(tmp_path):
    data=fake_catalog()
    def fetch(relative, limit=999999):
        if relative=='api/v1/catalog.json':
            return data
        if relative.startswith('component-content/'):
            return {'content':'# Safe source note\nUseful code review checklist.'}
        raise ValueError(relative)
    r=NativeRegistry(fetch, snapshot_path=tmp_path/'cache'/'catalog.json.gz')
    return r


def test_full_import_all_2000_by_type(registry):
    status=registry.status()
    assert status['registered_total']==2000
    assert all(status['by_type'][kind]==250 for kind in TYPES)
    assert status['native_registry'] and status['read_only']
    assert not status['paid_model_api_calls']
    assert status['origin']=='aitmpl-api-v1'
    assert len(status['fingerprint_sha256'])==64


def test_paginated_complete_without_duplicates(registry):
    cursor=0; ids=set(); pages=0
    while cursor is not None:
        page=registry.list(offset=cursor,limit=73)
        for entry in page['items']:
            assert entry['id'] not in ids
            ids.add(entry['id'])
        cursor=page['next_offset'];pages+=1
    assert len(ids)==2000 and pages>20


def test_text_adapters_are_useful_without_execution(registry):
    for kind in ('agents','commands','skills','loops'):
        candidate=next(i for i in registry.refresh().items if i.startswith(kind+'/'))
        prepared=registry.prepare(candidate)
        assert prepared['type']==kind
        assert prepared['capability_state']=='text-recipe-prepared-not-executed'
        assert prepared['text'].startswith('# Safe source')
        assert not prepared['external_model_invoked']
        assert not prepared['external_code_executed']


def test_runtime_components_are_indexed_but_not_started(registry):
    for kind in ('mcps','settings','hooks','mods'):
        cid=next(i for i in registry.refresh().items if i.startswith(kind+'/'))
        info=registry.prepare(cid)
        assert info['capability_state']=='reference-without-execution'
        assert info['kairos_mode']=='descriptor-only'
        assert 'needs' in info


def test_composition_limited_and_nonexecuting(registry):
    ids=['skills/kairos/test-5','agents/kairos/test-0']
    r=registry.compose(ids)
    assert len(r['profiles'])==2 and r['independent_llm_agents_created']==0
    assert r['execution_engine']=='current-chat-model-and-authorized-tools'
    with pytest.raises(ValueError):registry.compose(ids*4)
    with pytest.raises(ValueError):registry.compose([ids[0],ids[0]])


def test_search_query_find_and_filter(registry):
    r=registry.search('debugging',kind='skills',limit=4)
    assert r['matching_total']==250
    assert all(i['type']=='skills' for i in r['items'])
    with pytest.raises(ValueError):registry.search('',limit=10)


def test_duplicate_and_traversal_fail_closed(registry):
    payload=fake_catalog(3)
    payload['components'][1]['id']=payload['components'][0]['id']
    with pytest.raises(ValueError):NativeRegistry._parse(payload,'test')
    payload=fake_catalog(3)
    payload['components'][0]['id']='skills/../../.env'
    with pytest.raises(ValueError):NativeRegistry._parse(payload,'test')
    with pytest.raises(ValueError):registry.get('hooks/a/../../secret')


def test_cache_snapshot_fallback_when_network_off(tmp_path):
    data=fake_catalog(128)
    p=tmp_path/'sub'/'index.json.gz'
    r=NativeRegistry(lambda *_args,**_kwargs:data,p)
    assert r.status()['registered_total']==128 and p.exists()
    def offline(*args,**kwargs):raise TimeoutError('offline')
    other=NativeRegistry(offline,p)
    state=other.status()
    assert state['registered_total']==128
    assert state['origin']=='cached-snapshot-stale'
    assert state['last_error']


def test_changed_catalog_reloads_without_side_effects(registry):
    fst=registry.status()['fingerprint_sha256']
    original=registry.fetch
    def changed(path,limit=999999):
        result=original(path,limit)
        if path=='api/v1/catalog.json':
            result=copy.deepcopy(result)
            result['components'].append({'id':'skills/new/a','type':'skills','name':'new','license':None,'urls':{}})
            result['count']=len(result['components'])
        return result
    registry.fetch=changed
    updated=registry.refresh(force=True)
    assert len(updated.items)==2001 and updated.fingerprint !=fst


def test_no_forged_content_url_fetched(registry):
    original=registry.fetch
    paths=[]
    def traced(path,limit=999999):
        paths.append(path)
        return original(path,limit)
    registry.fetch=traced
    c=registry.refresh().items['skills/kairos/test-5']
    c['urls']['content']='https://evil.example.com/steal?token=x'
    registry.prepare('skills/kairos/test-5')
    assert paths[-1]=='component-content/skills/kairos/test-5.json'
    assert all(not p.startswith('https://evil.example.com/') for p in paths)


def test_full_mcp_wire_contract_with_2000_registry(monkeypatch,tmp_path):
    data=fake_catalog(2000)
    def fetch(path,limit=gateway.MAX_SIZE):
        if path == 'api/v1/catalog.json':return data
        if path.startswith('component-content/'):return {'content':'# Example safe instruction'}
        return {'schemaVersion':'1.0.0','count':2000}
    monkeypatch.setattr(gateway, 'fetch', fetch)
    monkeypatch.setattr(gateway, 'REGISTRY',NativeRegistry(fetch,tmp_path/'snap.gz'))
    with TestClient(gateway.app) as client:
        l=client.post('/mcp',json={'jsonrpc':'2.0','id':1,'method':'tools/list'})
        assert l.status_code==200
        tools=l.json()['result']['tools']
        assert len(tools)==14
        assert all(x['annotations']['readOnlyHint'] for x in tools)
        s=client.post('/mcp',json={'jsonrpc':'2.0','id':2,'method':'tools/call','params':{'name':'kairos_registry_status','arguments':{}}})
        assert s.status_code==200
        status=json.loads(s.json()['result']['content'][0]['text'])
        assert status['registered_total']==2000
        p=client.post('/mcp',json={'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'kairos_component_prepare','arguments':{'component_id':'skills/kairos/test-5'}}})
        assert not p.json()['result']['isError']
        assert json.loads(p.json()['result']['content'][0]['text'])['text'].startswith('# Example')
        assert client.get('/health').json()['indexed_components']==2000


def test_mcp_tool_errors_are_isolated(monkeypatch,tmp_path):
    monkeypatch.setattr(gateway,'REGISTRY',NativeRegistry(lambda *_args,**_kwargs:fake_catalog(2),tmp_path/'snap.gz'))
    with TestClient(gateway.app) as client:
        resp=client.post('/mcp',json={'jsonrpc':'2.0','id':7,'method':'tools/call','params':{'name':'kairos_component_prepare','arguments':{'component_id':'skills/../../BAD'}}})
        assert resp.json()['result']['isError']
